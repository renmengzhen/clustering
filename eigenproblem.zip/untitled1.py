#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Mar 28 22:42:10 2024
check distribution
@author: Mengzhen
"""
#%%
import matplotlib.pyplot as plt
import numpy as np
import itertools
import pandas as pd
from random import sample
from numpy.random import uniform
from math import isnan
import random
import scipy as sp
from scipy.optimize import minimize

from qiskit.quantum_info import Pauli, Operator, state_fidelity
from qiskit.circuit import QuantumCircuit, ParameterVector, Parameter
from qiskit import transpile
from qiskit_aer.noise import NoiseModel,depolarizing_error, amplitude_damping_error
from qiskit_aer import AerSimulator,QasmSimulator,StatevectorSimulator


#from qiskit.algorithms.minimum_eigensolvers import AdaptVQE, VQE
#from qiskit.algorithms.optimizers import SLSQP
from qiskit.primitives import Estimator
from qiskit.quantum_info import SparsePauliOp
#%% hamiltonian
def Heisenberg(N,J_x,J_y,J_z):
    J = [J_x,J_y,J_z]
    pp = 0
    H = np.zeros(shape=(2**N,2**N))
    label=[]
    coeff=[]
    for p in ['X','Y','Z']:
        pauli_p = [p*2]+list(itertools.repeat('I',N-2))
        add_p = [p]+list(itertools.repeat('I',N-2))+[p]
        comb_p = list(set(itertools.permutations(pauli_p,N-1)))
        comb_p.append(list(add_p))
        H_p = np.zeros(shape=(2**N,2**N))
        for i in range(len(comb_p)):
            pauli_p = ''
            for j in range(len(comb_p[i])):
                pauli_p = pauli_p+comb_p[i][j]
            label.append(pauli_p)
            H_p = H_p+Pauli(pauli_p).to_matrix()
        H = H+J[pp]*H_p
        coeff = coeff+[-0.5*J[pp]]*len(comb_p)
        pp = pp+1
    
    pauli_z = ['Z']+list(itertools.repeat('I',N-1))
    comb_z = list(set(itertools.permutations(pauli_z,N)))   
    H_z = np.zeros(shape=(2**N,2**N))
    for i in range(len(comb_z)):
        pauli_z = ''
        for j in range(len(comb_z[i])):
            pauli_z = pauli_z+comb_z[i][j]
        label.append(pauli_z)
        H_z = H_z+Pauli(pauli_z).to_matrix()
    coeff=coeff+[-0.5]*len(comb_z)
    
    H_fin = -0.5*(H+H_z)
    H_spo = SparsePauliOp(label, coeff)   
    return H_fin,H_spo

# hamiltonian = SparsePauliOp.from_list(
#     [("YZZZ", 0.3980), ("ZIII", -0.3980), ("ZZII", -0.0113), ("XXII", 0.1810)]
# )
# Hp=hamiltonian.to_matrix()
# hamiltonian = SparsePauliOp.from_list(
#     [("YZZZ", 0.3980), ("ZIII", -0.3980), ("ZZII", -0.0113), ("XXII", 0.1810)]
# )

#%% ansatz
def makewave0(wavefunction,dele,name):
    n = wavefunction.num_qubits
    param = ParameterVector(name,int(3*n+n**2))
    t=0
    for depth in range(1):
        for i in range(n):
            wavefunction.rz(param[t], i)
            t+=1
        for i in range(n):
            for j in range(n):
                if j!=i:
                    wavefunction.cry(param[t],i,j)
                    t+=1
        wavefunction.barrier()
    for k in range(n):
        wavefunction.ry(param[t],k)
        t+=1
    return wavefunction

# sample
# noise
map_type='jordan_wigner'
# backend = StatevectorSimulator(method="statevector")
noise_model = NoiseModel()
errate=0#0
error = depolarizing_error(errate, 1)
noise_model.add_all_qubit_quantum_error(error,["u1", "u2", "u3"])
errate=0#0,0.001,0.005,0.01,0.015,0.02,0.025,0.03,0.04,0.045,0.05
error = depolarizing_error(errate, 2)
noise_model.add_all_qubit_quantum_error(error,'cx')
sim_noise = QasmSimulator(noise_model=noise_model)

# state
def Lv(params,wavefunction):
    a={}
    t=0
    for i in wavefunction.parameters:
        a[i]=params[t]
        t+=1
    qc = wavefunction.assign_parameters(a)
    #qc.snapshot_density_matrix('final')
    #qp.save_density_matrix(qc,label='final')
    #qc.snapshot()
    qc.save_statevector()
    # qc.snapshot(label='final',snapshot_type='statevector')
    qc.measure_all()
    # U=[]
    # for i in range(100):
    circ_noise = transpile(qc, sim_noise)
    noise_result = sim_noise.run(circ_noise,shots=1).result()
    u=noise_result.get_statevector()
    # U.append(u)
    # u=sum(U)/10
    # counts = noise_result.get_counts(qc)
    # u=np.zeros(2**wavefunction.num_qubits)
    # for i in list(counts):
    #     u[int(i,2)]=counts[i]
    # u/=sum(u)
    # u=np.sqrt(u)
    return np.array(u)

def sf(v,u,w):
    sf_v = []
    us=np.argsort(u)
    for i in us:
        sf_v.append(state_fidelity(v, w[:,i]))
        #print(state_fidelity(v, w[:,i]))
    return sf_v
#%% vqe
def cost_func(params, ansatz, hamiltonian, estimator):
    """Return estimate of energy from estimator

    Parameters:
        params (ndarray): Array of ansatz parameters
        ansatz (QuantumCircuit): Parameterized ansatz circuit
        hamiltonian (SparsePauliOp): Operator representation of Hamiltonian
        estimator (EstimatorV2): Estimator primitive instance

    Returns:
        float: Energy estimate
    """
    #pub = ([ansatz], [hamiltonian], [params])
    #result = estimator.run(pubs=[pub]).result()
    #energy = result[0].data.evs[0]
    job = estimator.run([ansatz], [hamiltonian], [params])
    job_result = job.result()
    energy = job_result.values[0]

    return energy

# def build_callback(ansatz, hamiltonian, estimator, callback_dict):
#     """Return callback function that uses Estimator instance,
#     and stores intermediate values into a dictionary.

#     Parameters:
#         ansatz (QuantumCircuit): Parameterized ansatz circuit
#         hamiltonian (SparsePauliOp): Operator representation of Hamiltonian
#         estimator (EstimatorV2): Estimator primitive instance
#         callback_dict (dict): Mutable dict for storing values

#     Returns:
#         Callable: Callback function object
#     """

#     def callback(current_vector):
#         """Callback function storing previous solution vector,
#         computing the intermediate cost value, and displaying number
#         of completed iterations and average time per iteration.

#         Values are stored in pre-defined 'callback_dict' dictionary.

#         Parameters:
#             current_vector (ndarray): Current vector of parameters
#                                       returned by optimizer
#         """
#         # Keep track of the number of iterations
#         callback_dict["iters"] += 1
#         # Set the prev_vector to the latest one
#         callback_dict["prev_vector"] = current_vector
#         # Compute the value of the cost function at the current vector
#         # This adds an additional function evaluation
#         pub = (ansatz, [hamiltonian], [current_vector])
#         result = estimator.run(pubs=[pub]).result()
#         current_cost = result[0].data.evs[0]
#         callback_dict["cost_history"].append(current_cost)
#         # Print to screen on single line
#         print(
#             "Iters. done: {} [Current cost: {}]".format(callback_dict["iters"], current_cost),
#             end="\r",
#             flush=True,
#         )

#     return callback
# callback_dict = {
#     "prev_vector": None,
#     "iters": 0,
#     "cost_history": [],
# }

#%% main
n=4
J_x=2+np.random.random()
J_y=2.5+np.random.random()
J_z=3+np.random.random()
Hp,hamiltonian=Heisenberg(n, J_x, J_y, J_z)
u,w = sp.sparse.linalg.eigs(Hp,k=5,which='SR')


dele=[]
wavefunction = QuantumCircuit(n)
for i in range(n):
    wavefunction.h(i)
wavefunction = makewave0(wavefunction, dele,1)
#wavefunction.draw('mpl')
N=wavefunction.num_parameters
x0 = 0.1 * np.pi * np.random.random(N)

estimator = Estimator()
estimator.options.default_shots = 1000

ansatz=wavefunction
#ansatz_isa=wavefunction
#hamiltonian_isa=hamiltonian

#callback = build_callback(ansatz_isa, hamiltonian_isa, estimator, callback_dict)

res = minimize(
    cost_func,
    x0,
    args=(ansatz, hamiltonian, estimator),
    method="cobyla",
    #callback=callback,
    )

x1=res.x
phi = Lv(x1,ansatz)
np.argsort(sf(phi,u,w))[::-1]
#np.round(sf(phi,u,w)[0]/sum(sf(phi,u,w)),3)
plt.plot(abs(phi))
plt.plot(abs(w[:,0]))

#%% compare
def prob_amp(state,dec):
    amp=np.around(abs(state),dec)
    prob=np.zeros(np.size(amp))
    for i in range(np.size(amp)):
        prob[i]=amp[i]**2
    return prob/sum(prob)

def compare(state,target,dec):
    prob_hat=prob_amp(state, dec)
    prob = prob_amp(target, dec)
    act_num = 0
    exa_num = 0
    hat_num = 0 
    prob_sum=0
    actprob_sum=0
    eps = 0.1/2**n #1e-5
    for i in range(np.size(prob)):
        if prob[i]>eps:
            exa_num+=1
            prob_sum=prob_sum+prob[i]
            if prob_hat[i]>eps:
                act_num+=1
                actprob_sum=actprob_sum+prob[i]
        if prob_hat[i]>eps:
            hat_num+=1
    return exa_num/2**n, hat_num/2**n, np.around(act_num/exa_num,3), actprob_sum, np.around(actprob_sum/prob_sum,3)


#%%
h4=np.zeros(shape=(5,5))
for m in range(5):
    n=10
    J_x=2+np.random.random()
    J_y=2.5+np.random.random()
    J_z=3+np.random.random()
    Hp,hamiltonian=Heisenberg(n, J_x, J_y, J_z)
    u,w = sp.sparse.linalg.eigs(Hp,k=5,which='SR')
    dele=[]
    wavefunction = QuantumCircuit(n)
    for i in range(n):
        wavefunction.h(i)
    wavefunction = makewave0(wavefunction, dele,1)
    #wavefunction.draw('mpl')
    N=wavefunction.num_parameters
    x0 = 0.1 * np.pi * np.random.random(N)

    estimator = Estimator()
    estimator.options.default_shots = 2e3

    ansatz=wavefunction
    res = minimize(
        cost_func,
        x0,
        args=(ansatz, hamiltonian, estimator),
        method="cobyla",
        #callback=callback,
        )
    x1=res.x
    phi = Lv(x1,ansatz)
    h4[m,:]=compare(phi,w[:,0],5)

#%%
avg=np.zeros(shape=(4,5))
#%%
avg[0,:]=np.mean(h4,0)#4,6,8,10







