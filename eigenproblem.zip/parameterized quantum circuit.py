#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon May  1 06:25:16 2023

@author: Mengzhen
"""
#%% define qc with parameter
from qiskit.circuit import QuantumCircuit, Parameter
theta = Parameter('θ')

qc = QuantumCircuit(2)
qc.rz(theta, 0)
qc.crz(theta, 0, 1)
qc.draw('mpl')

#%% different parameters
from qiskit.circuit import ParameterVector
theta_list = ParameterVector('θ', length=2)

qc = QuantumCircuit(2)
qc.rz(theta_list[0], 0)
qc.crz(theta_list[1], 0, 1)
qc.draw()

#%% show in bloch
import numpy as np
import matplotlib.pyplot as plt

# First, we need to define the circuits:
theta_param = Parameter('θ')
phi_param = Parameter('Φ')

# Circuit A
qc_A = QuantumCircuit(1)
qc_A.h(0)
qc_A.ry(theta_param, 0)
qc_A.draw('mpl')

# Circuit B
num_theta_list = 5
qc_B = QuantumCircuit(2)
theta_list = ParameterVector('θ', length=num_theta_list)
param = 0
for i in range(2):
    qc_B.h(i)
    qc_B.rz(theta_list[param], i)
    param = param+1
    qc_B.ry(theta_list[param], i)
    param = param+1
qc_B.crx(theta_list[param], 0,1)
param = param+1
qc_B.draw('mpl')

# Next we uniformly sample the parameter space for the two parameters theta and phi
np.random.seed(0)
num_param = 1000
theta = [2*np.pi*np.random.uniform() for i in range(num_param)]
# phi = [2*np.pi*np.random.uniform() for i in range(num_param)]
theta_list_param = []
for i in range(num_theta_list):
    theta_list_param.append([2*np.pi*np.random.uniform() for i in range(num_param)])

# Then we take the parameter value lists, build the state vectors corresponding
# to each circuit, and plot them on the Bloch sphere:
from qiskit.visualization.bloch import Bloch
from qiskit.quantum_info import Statevector

def state_to_bloch(state_vec):
    # Converts state vectors to points on the Bloch sphere
    phi = np.angle(state_vec.data[1])-np.angle(state_vec.data[0])
    theta = 2*np.arccos(np.abs(state_vec.data[0]))
    return [np.sin(theta)*np.cos(phi),np.sin(theta)*np.sin(phi),np.cos(theta)]

# Bloch sphere plot formatting
width, height = plt.figaspect(1/2)
fig=plt.figure(figsize=(width, height))
ax1, ax2 = fig.add_subplot(1, 2, 1, projection='3d'), fig.add_subplot(1, 2, 2, projection='3d')
b1,b2 = Bloch(axes=ax1), Bloch(axes=ax2)
b1.point_color, b2.point_color = ['tab:blue'],['tab:blue']
b1.point_marker, b2.point_marker= ['o'],['o']
b1.point_size, b2.point_size=[2],[2]

# Calculate state vectors for circuit A and circuit B for each set of sampled parameters
# and add to their respective Bloch sphere
for i in range(num_param):    
    state_1=Statevector.from_instruction(qc_A.bind_parameters({theta_param:theta[i]}))
    # state_2=Statevector.from_instruction(qc_B.bind_parameters({theta_param:theta[i], phi_param:phi[i]}))
    d_param = {}
    for k in range(num_theta_list):
        d_param[theta_list[k]] = theta_list_param[k][i]
    state_2=Statevector.from_instruction(qc_B.bind_parameters(d_param))
    b1.add_points(state_to_bloch(state_1))
    b2.add_points(state_to_bloch(state_2))

b1.show()
b2.show()