#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Oct 31 08:30:05 2023

@author: Mengzhen
"""
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from geomstats.geometry.spd_matrices import SPDMatrices
import geomstats.backend as gs
from geomstats.datasets.prepare_emg_data import TimeSeriesCovariance
from geomstats.learning.frechet_mean import FrechetMean
from geomstats.geometry.spd_matrices import SPDAffineMetric


X_H = pd.read_excel('00no_25_EE1h1.xlsx').iloc[:,-12:]

data = X_H.iloc[:,-13:]
data_0 = data[data['class']==0].iloc[:,-12:].values
data_1 = data[data['class']==1].iloc[:,-12:]
data_2 = data[data['class']==2].iloc[:,-12:]
data_3 = data[data['class']==0].iloc[:,-12:]
data_4 = data[data['class']==1].iloc[:,-12:]
data_5 = data[data['class']==2].iloc[:,-12:]

cov_data_0 = np.zeros((np.size(data[data['class']==0],0),12,12))
for i in range(np.size(data[data['class']==0],0)):
    cov_data_0[i,:,:]=np.cov(data_0[i,:].reshape(12,1),bias=True)

cov_data_0 = np.cov(data_0.T,bias=True)
cov_data_1 = np.cov(data_1.T,bias=True)
cov_data_2 = np.cov(data_2.T,bias=True)
cov_data_3 = np.cov(data_3.T,bias=True)
cov_data_4 = np.cov(data_4.T,bias=True)
cov_data_5 = np.cov(data_5.T,bias=True)


manifold = SPDMatrices(12, equip=False)
gs.all(manifold.belongs(cov_data_0))



plt.matshow(cov_data_0, cmap=plt.cm.Reds)


fig, axes = plt.subplots(3, 2, sharex=True, sharey=True)
axes[0, 0].matshow(cov_data_0, cmap=plt.cm.Reds)
axes[0, 1].matshow(cov_data_1, cmap=plt.cm.Reds)
axes[1, 0].matshow(cov_data_2, cmap=plt.cm.Reds)
axes[1, 1].matshow(cov_data_3, cmap=plt.cm.Reds)
axes[2, 0].matshow(cov_data_4, cmap=plt.cm.Reds)
axes[2, 1].matshow(cov_data_5, cmap=plt.cm.Reds)
fig.legend()
plt.tight_layout()

#%%
manifold.equip_with_metric(SPDAffineMetric)
mean_affine = FrechetMean(manifold)

mean_affine.fit(data_0)
mean_cov = mean_affine.estimate_
#%%
import numpy as np
from qiskit.circuit import QuantumCircuit, ParameterVector, Parameter
def makewave(wavefunction,name):
    n = wavefunction.num_qubits
    param = ParameterVector(name,int((4*n-4)*3))
    t=0
    for depth in range(1):
        for i in range(n):
            wavefunction.ry(param[t], i)
            t+=1
            wavefunction.rz(param[t], i)
            t+=1
        for j in range(int(n/2)):
            wavefunction.cnot(2*j+1,2*j)
        for i in range(n):
            if i>0 and i<n-1:
                wavefunction.ry(param[t], i)
                t+=1
                wavefunction.rz(param[t], i)
                t+=1
        for j in range(int(n/2)):
            if j>0 and j<int(n/2):
                wavefunction.cnot(2*j,2*j-1)
    return wavefunction

n=6 #4,12
wavefunction = QuantumCircuit(n)
makewave(wavefunction,1)
wavefunction.draw('mpl')
N=wavefunction.num_parameters
#%%
data = pd.read_excel('eigenproblem/h1n6_00no_25step_0.xlsx').iloc[:,2:]
data = np.array(data)
Y = data[:,0]
X = data[:,1:]

# LASSO
from sklearn.linear_model import LogisticRegression
from sklearn.feature_selection import SelectFromModel
logistic = LogisticRegression(penalty='l1',C=15,solver='saga',random_state=1)
selected = SelectFromModel(estimator=logistic).fit(X,Y)

coe=selected.estimator_.coef_
coe = np.sum(abs(coe),0)

real_imag = np.zeros(28)
for i in range(28):
    real_imag[i] = coe[i]+coe[28+i]
    
ry_rz = np.zeros(2)
for i in range(28):
    ry_rz[0]=ry_rz[0]+coe[2*i]
    ry_rz[1]=ry_rz[1]+coe[2*i+1]
    
# Fisher Score
def fisher_score(sample,label):
    df_sample = pd.DataFrame(sample)
    df_sample.insert(0, 'class', label)
    num_feature = np.size(sample,1)
    #num_sample = np.size(sample,0)
    num_class = len(set(label))
    
    S_B = np.zeros(num_feature)
    S_W = np.zeros(num_feature)
    m = np.zeros(shape=(num_class,num_feature))
    n = np.zeros(num_class)
    for i in range(num_class):
        m[i,:] = np.mean(df_sample[df_sample['class']==i].iloc[:,1:],0)           
        n[i] = len(df_sample[df_sample['class']==i])
    
    for k in range(num_feature):
        for i in range(num_class):
            S_B[k] = S_B[k]+n[i]*(m[i,k]-np.mean(m[:,k]))**2
            S_W[k] = S_W[k]+sum((sample[df_sample['class']==i][:,k]-m[i,k])**2)
    fisher = S_B/S_W
    # for k in range(num_feature):
    #     if S_B[k]<0.01 or S_W[k]<0.001:
    #         fisher[k]=0
    return fisher

fisher = fisher_score(X,Y)
# for k in range(len(fisher)):
#     if fisher[k]>5*np.percentile(fisher,90,interpolation = 'midpoint'):
#         fisher[k]=0

# ry_rz = np.zeros(2)
# for i in range(int(0.5*len(fisher))):
#     ry_rz[0]=ry_rz[0]+fisher[2*i]
#     ry_rz[1]=ry_rz[1]+fisher[2*i+1]

ind = []
for k in range(len(fisher)):
    if fisher[k]<np.percentile(fisher,30,interpolation = 'midpoint'):
        ind.append(k)
odd = 0
even = 0
for j in range(len(ind)):
    if ind[j]%2==1:
        odd=odd+1
    if ind[j]%2==0:
        even=even+1

# or use >0.3
ind = []
for k in range(len(fisher)):
    if fisher[k]>np.percentile(fisher,30,interpolation = 'midpoint'):
        ind.append(k)

odd = 0
even = 0
for j in range(len(ind)):
    if ind[j]%2==1:
        odd=odd+1
    if ind[j]%2==0:
        even=even+1
drop_odd =  0.5*len(fisher)-odd
drop_even =  0.5*len(fisher)-even

# loop
p = int(0.5*len(fisher))
ind_p=[]
for j in range(len(ind)):
    ind_p.append(ind[j]%p)

dele = set(ind_p)
n=12
wavefunction = QuantumCircuit(n)
for i in range(n):
    wavefunction.h(i)
wavefunction = makewave(wavefunction, dele,1)
wavefunction.draw('mpl')
N=wavefunction.num_parameters

#%% plot
import matplotlib.pyplot as plt
import numpy as np

x_labels = ['6', '8', '10', '12']
rz = [11, 16, 19, 23]
ry = [1, 1, 3, 4]

error_0 = [0.038377514, 0.020959445, 0.01680659, 0.010752781]
error_1 = [0.051823162, 0.018115017, 0.008061046, 0.007031313]


legend_labels = ['rz', 'ry']
y = [rz, ry]

fig = plt.figure(figsize=(8, 6))
ax = fig.add_subplot(facecolor='white')
color_list = ['y','c']
x_loc = np.arange(4)
total_width = 0.8
total_num = 2
each_width = total_width / total_num
if total_num % 2 == 0:
    x1 = x_loc - (total_num / 2 - 1) * each_width - each_width / 2
else:
    x1 = x_loc - ((total_num - 1) / 2) * each_width
x_list = [x1 + each_width * i for i in range(total_num)]
print(x_list)

for i in range(0, len(y)):
    ax.bar(x_list[i], y[i], color=color_list[i], width=each_width, label=legend_labels[i])
ax.set_xticks(x_loc)
ax.set_xticklabels(x_labels)
ax.grid(True, ls=':', color='b', alpha=0.3)
ax.set_xlabel('number of qubit', fontweight='bold')
ax.set_ylabel('number of rotation gate', fontweight='bold')
# plt.title('sacling', fontweight='bold', pad=25)
# 
ax_twinx = ax.twinx()
ax_twinx.plot(x_loc, error_0, linestyle='-', marker='o', markersize=3, color='r', label='MRE 1')
ax_twinx.plot(x_loc, error_1, linestyle=':', marker='o', markersize=3, color='b', label='MRE 2')
fig.legend(loc='upper center', bbox_to_anchor=(0.5, 0.96), frameon=False, ncol=5, handlelength=0.9, handleheight=0.9, fontsize='small')
ax_twinx.set_ylabel('Mean Relative Error (MRE)', fontweight='bold')
fig.tight_layout()
fig.subplots_adjust(top=0.9)
plt.show()

    





