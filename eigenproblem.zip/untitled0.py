#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Dec  5 09:32:35 2022

@author: Mengzhen
"""

# from qiskit 
from qiskit.tools.visualization import plot_histogram
from qiskit.quantum_info import Operator, Statevector, Pauli, state_fidelity
from qiskit.tools.monitor import job_monitor
# from qiskit.ignis.mitigation.measurement import *

import numpy as np
import random
import matplotlib.pyplot as plt
import math
import cmath
import itertools
from scipy.linalg import expm,eigh

import pandas as pd




# Heisenberg model
def Heisenberg(N,J_x,J_y,J_z):
    J = [J_x,J_y,J_z]
    pp = 0
    H = np.zeros(shape=(2**N,2**N))
    for p in ['X','Y','Z']:
        pauli_p = [p*2]+list(itertools.repeat('I',N-2))
        add_p = [p]+list(itertools.repeat('I',N-2))+[p]
        comb_p = list(set(itertools.permutations(pauli_p,N-1)))
        comb_p.append(list(add_p))
        H_p = np.zeros(shape=(2**N,2**N))
        for i in range(len(comb_p)):
            pauli_p = ''
            for j in range(len(comb_p[i])):
                pauli_p = pauli_p+comb_p[i][j]
            H_p = H_p+Pauli(pauli_p).to_matrix()
        H = H+J[pp]*H_p
        pp = pp+1
    
    pauli_z = ['Z']+list(itertools.repeat('I',N-1))
    comb_z = list(set(itertools.permutations(pauli_z,N)))   
    H_z = np.zeros(shape=(2**N,2**N))
    for i in range(len(comb_z)):
        pauli_z = ''
        for j in range(len(comb_z[i])):
            pauli_z = pauli_z+comb_z[i][j]
        H_z = H_z+Pauli(pauli_z).to_matrix()
    
    H_fin = -0.5*(H+H_z)
    return H_fin


def sf(v,u,w):
    sf_v = []
    us=np.argsort(u)
    for i in us:
        sf_v.append(state_fidelity(v, w[:,i]))
        #print(state_fidelity(v, w[:,i]))
    return sf_v

N = 2
H = Heisenberg(N, 0.2, 0.5, 0.8)
# v = np.mat(1/math.sqrt(2**N)*np.ones(shape=(2**N,1)))
# v = np.mat()
v=np.mat(np.random.random(2**N)).T
v = v*1/math.sqrt(v.T.conjugate()*(v))
u,w = np.linalg.eigh(H)
        
#%%
def Algorithm_11(H,N,v,lambda_0,K,timestep_size,strengthstep_size,total_steps,eps):
    # initial
    lambda_total = [lambda_0]
    dt = timestep_size
    ds = strengthstep_size
    s = 0
    i = 0
    # loop
    while i<K:
        ft = [lambda_total[-1]]
        t_num = 1
        s = s+ds
        while t_num<total_steps :
            H2 = (H-lambda_0*Pauli('I'*N).to_matrix()).dot(H-lambda_0*Pauli('I'*N).to_matrix())
            t = t_num*dt
            At = expm((-(H2-s*H)*t))
            At_v = np.mat(At)*v
            Ut_v = At_v/cmath.sqrt(At_v.T.conjugate()*(At_v))
            ftt = (Ut_v.T.conjugate()).dot(H*Ut_v)
            ft.append(ftt)
            #if (ft[-1]-ft[-2])**2<eps**2*10:
                #s = s+ds
            if (ft[-1]-ft[-2])**2<eps**2:
                break
            t_num = t_num+1
        if total_steps-t_num<10 and i>0:
            s = s-lambda_total[-1]
            print(s)
        if (ft[-1]-lambda_total[-1])**2>eps**2 and t_num<total_steps-10:
            lambda_total.append(ft[-1].real)
            i = i+1
            # s = ds
    # output
    # np.around(lambda_total,3)
    return lambda_total     
        
#%%
# Algorithm 22
def Algorithm_22(H,N,v,K,timestep_size,total_steps,eps,n,beta_1,beta_2,lambda_k,lambda_max):
    # initial
    dt = timestep_size
    #s = 0.1*np.around(lambda_max-lambda_k,3)
    lambda_total = [lambda_k]
    lambda_hat = []
    f = []
    sfv = []
    i=0
    # M = lambda_k+10*eps
    t_num = 1
    # loop
    while i<K:
        ft = [lambda_total[-1]]
        t_num = 1
        test = 1
        j = 0
        while j<n+1:
            t_num = 1
            test = 1
            Hp = np.zeros(shape=(2,2))
            G = Pauli('I').to_matrix()
            H2 = np.dot((H-lambda_total[-1]*Pauli('I'*N).to_matrix())
                            ,(H-lambda_total[-1]*Pauli('I'*N).to_matrix()))
            # s = np.around((lambda_max-lambda_k)/(1+np.exp(j+1)),3)
            # s = 0.5*np.around((lambda_max-lambda_total[-1])/(j+1),3)
            s = 0.8*j
            #print(s)
            while t_num<total_steps and test==1:
                t = t_num*dt
                At_j = expm(-H2*t+s*H)
                At_j_v = np.mat(At_j)*v
                Ut_j_v = At_j_v/cmath.sqrt(At_j_v.T.conjugate()*(At_j_v))
                ftt = (Ut_j_v.T.conjugate()).dot(H*Ut_j_v)
                ft.append(ftt[0,0])
                f.append(ftt[0,0])
                dft = (ft[-1]-ft[-2])/dt
                # print(dft)
                if dft.T.conjugate()*dft>beta_2**2:
                    phi_2 = Ut_j_v
                    sfv.append(sf(phi_2,u,w))
                    # print(len(sfv))
                if dft.T.conjugate()*dft<beta_1**2:
                    phi_1 = Ut_j_v
                    #print(s)
                    Hp[0,0] = (phi_1.T.conjugate()*H*phi_1)[0,0]
                    Hp[0,1] = (phi_1.T.conjugate()*H*phi_2)[0,0]
                    Hp[1,0] = (phi_2.T.conjugate()*H*phi_1)[0,0]
                    Hp[1,1] = (phi_2.T.conjugate()*H*phi_2)[0,0]
                    G[0,1] = (phi_1.T.conjugate()*phi_2)[0,0]
                    G[1,0] = (phi_2.T.conjugate()*phi_1)[0,0]                                     
                    lambda_new = eigh(Hp,G)
                    lambda_new = lambda_new[0]
                    if (lambda_new[-1]-lambda_new[-2]).T.conjugate()*(lambda_new[-1]-lambda_new[-2])>1e-3:             
                        lambda_hat.append(lambda_new[-1])
                    test = 0
                
                #if (ft[-1]-M).T.conjugate()*(ft[-1]-M)<eps**2:
                    #test = 0  
                t_num = t_num+1
            j = j+1
        if (lambda_hat[-1]-lambda_total[-1])**2>eps**2:
            lambda_total.append(np.array(lambda_hat).reshape(-1)[-1])
            #lambda_total.append(lambda_hat[-1].real)
            # M = lambda_total[-1]+10*eps
            i = i+1
    # output
    # lambda_total
    return np.around(lambda_total,10),f,sfv

#%%

Algorithm_11(H,N,v,-6,1,0.1,0.8,1000,0.001)

Algorithm_22(H,N,v,3,0.1,1,10000,0.001,4,-0.0001,-0.001,-2)   
        
lam,f,sfv=Algorithm_22(H,N,v,4,0.05,10000,0.001,1,-0.0001,-0.01,u[0],u[-1])    
plt.plot(f)
for i in range(int(len(sfv)/50)):
    plt.plot(sfv[i*50],c=(i/int(len(sfv)/50),0.5,0.5))
plt.plot(sfv[-1],c='r')
        
# error with diff shift m=2
error_m = np.zeros(10)
for m in range(10):
    lam,f,sfv=Algorithm_22(H,N,v,1,0.05,10000,0.001,m,-0.0001,-0.01,u[0],u[-1])
    error_m[m] = np.around(1-abs(lam[-1]-u[1])/abs(lam[-1]),5)
plt.scatter(range(len(error_m)-1),error_m[1:])
plt.xlabel('m')
plt.ylabel('accuracy')
plt.xticks(range(len(error_m)-1))
plt.ylim(0,1.1)
plt.axhline(0.8,0,100,color='r',linestyle=':')  
plt.text(5.6, 0.96, 0.94206)
        

#%% error with slope, m=2
error_b = np.zeros(shape=(60,3))
i = 0
step=[]

for b0 in range(-100,-1,2):
    b1 = b0*1e-4
    b2 = b1*(1+0.01)
    lam,f,sfv=Algorithm_22(H,N,v,1,0.05,10000,0.001,2,b1,b2,u[0],u[-1])
    error_b[i] = [b1,b2,1-abs(lam[-1]-u[1])/abs(lam[-1])]
    i = i+1
    step.append(len(f))

# plt.subplot(2,1,1)
# plt.hist(step)
# plt.plot(step,error_b[:i,2])
# #plt.plot([step[0],step[-1]],[error_b[:i,2][0],error_b[:i,2][-1]],'r',linestyle=':')
# plt.xlabel('step')
# plt.ylabel('accuracy')

# plt.subplot(2,1,2)
# plt.scatter(error_b[:i,0],error_b[:i,2])
# plt.xlabel('beta1')
# plt.ylabel('accuracy')

figure,(ax1,ax2) = plt.subplots(2,1,sharex=True)
ax1.plot(step,error_b[:i,2])
ax1.set_ylabel('accuracy')
ax2.hist(step)
ax2.set_ylabel('frequency')
plt.xlabel('step')

plt.scatter(error_b[:i,0],error_b[:i,2])
plt.xlabel('beta1')
plt.ylabel('accuracy')

#%% average error
N = 3
num_H = 20
H_total = np.zeros((num_H,2**N,2**N))
for h in range(num_H):
    num_H_x = np.around(random.uniform(-1,1),1)
    num_H_y = np.around(random.uniform(-1,1),1)
    num_H_z = np.around(random.uniform(-1,1),1)
    num_x = np.around(num_H_x/np.sqrt(num_H_x**2+num_H_y**2+num_H_z**2+1),1)
    num_y = np.around(num_H_y/np.sqrt(num_H_x**2+num_H_y**2+num_H_z**2+1),1)
    num_z = np.around(num_H_z/np.sqrt(num_H_x**2+num_H_y**2+num_H_z**2+1),1)
    H_total[h] = Heisenberg(N,num_x,num_y,num_z)
    
error_u2 = np.zeros(shape=(num_H,1))

for h in range(num_H):
    print(h)
    H = np.mat(H_total[h])
    u,w = np.linalg.eigh(H)
    u = np.around(u,10)
    u = np.unique(u)
    lambda_0 = u[0]
    lambda_1 = u[-1]
    v=np.mat(np.random.random(2**N)).T
    v = v*1/math.sqrt(v.T.conjugate()*(v))
    
    ud_ind_sum = []
    u_hat = []
    while 1:
        #Alg2 = Algorithm_22(H,N,v,1,0.1,1,10000,0.001,3,-0.0001,-0.001,lambda_0)
        lam,f,sfv=Algorithm_22(H,N,v,2,0.05,10000,0.001,2,-0.0001,-0.01,lambda_0,lambda_1)
        u_add = ((np.around(lam[1:3],10)).reshape(2,1)).tolist()
        u_hat.extend(u_add)
        for uh_ind in range(len(u_hat)):
            u_delta = abs(u-u_hat[uh_ind])
            ud_ind = np.argmin(u_delta)
            ud_ind_sum.append(ud_ind)
        delta = 2-len(np.unique(ud_ind_sum))
        print(delta)
        if delta>0:
            lambda_0 = u_hat[-1][0]
        else:
            break
    ud_ind_fin = []
    for uh_ind in range(len(u_hat)):
        u_delta = abs(u-u_hat[uh_ind])
        ud_ind = np.argmin(u_delta)
        ud_ind_fin.append(ud_ind)
    err_add = abs((u[ud_ind_fin[0]]-u_hat[0])/u_hat[0])
    err_num = 1
    for i in range(len(ud_ind_fin)):
        if i>0 and ud_ind_fin[i]-ud_ind_fin[i-1]>0:
            if u_hat[i][0]>0.01 or u_hat[i][0]<-0.01:
                err_add = err_add+abs((u[ud_ind_fin[i]]-u_hat[i])/u_hat[i])
                err_num = err_num+1
    error_u2[h] = err_add/err_num
#%%
df = pd.DataFrame(error_u2)
df.to_excel('error2_3.xlsx')

plt.scatter(list(range(20)),np.maximum(1-error_u2,0))
plt.xticks(range(20))
plt.ylim(0,1.1)
plt.axhline(0.8,0,100,color='r')   
#plt.axhline(1.0,0,100,color='r')    
plt.show() 
a3_2 = np.mean(np.maximum(1-error_u2,0))    
        
        
        
        
        
        
        
        
        
        
        
        
        
        