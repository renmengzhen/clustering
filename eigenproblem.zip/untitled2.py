#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Dec 20 07:42:55 2022

@author: Mengzhen
"""

import matplotlib.pyplot as plt
import numpy as np
import itertools
import pandas as pd
from pandas.plotting import parallel_coordinates
from random import sample
from numpy.random import uniform
from math import isnan
import random

from qiskit import transpile
from qiskit.quantum_info import Pauli, Operator, state_fidelity
from qiskit.circuit import QuantumCircuit, ParameterVector, Parameter
#from qiskit.providers.aer.noise import NoiseModel,depolarizing_error, amplitude_damping_error
#from qiskit.providers.aer import AerSimulator,QasmSimulator,StatevectorSimulator
from qiskit_aer.noise import NoiseModel,depolarizing_error, amplitude_damping_error
from qiskit_aer import AerSimulator,QasmSimulator,StatevectorSimulator
# from qiskit_aer.library import save_statevector
from qiskit_nature.second_q.drivers import PySCFDriver
from qiskit_nature.units import DistanceUnit
from qiskit_nature.problems.second_quantization import ElectronicStructureProblem
from qiskit_nature.converters.second_quantization import QubitConverter
from qiskit_nature.mappers.second_quantization import JordanWignerMapper
#import qiskit.providers.aer.library as qp
from sklearn.cluster import KMeans, MeanShift, estimate_bandwidth, SpectralClustering, OPTICS, Birch, DBSCAN
from sklearn.decomposition import PCA
from sklearn.metrics import silhouette_score
from sklearn.neighbors import NearestNeighbors
from sklearn.manifold import TSNE
#import umap
#from scipy.optimize import minimize
import seaborn as sns
# Riemannian Geometry
#from geomstats.learning.kmeans import RiemannianKMeans
#from geomstats.geometry.grassmannian import Grassmannian

from qiskit_nature.drivers import UnitsType, Molecule
from qiskit_nature.second_q.drivers import MethodType
from qiskit_nature.drivers.second_quantization import (
    ElectronicStructureDriverType,
    ElectronicStructureMoleculeDriver,
)
from qiskit_nature.problems.second_quantization import ElectronicStructureProblem
from qiskit_nature.transformers.second_quantization.electronic import FreezeCoreTransformer, ActiveSpaceTransformer
from qiskit_nature.converters.second_quantization import QubitConverter
from qiskit_nature.mappers.second_quantization import JordanWignerMapper, BravyiKitaevMapper, ParityMapper
import scipy as sp

#%%
map_type='jordan_wigner'
# backend = StatevectorSimulator(method="statevector")
noise_model = NoiseModel()
errate=0#0
error = depolarizing_error(errate, 1)
noise_model.add_all_qubit_quantum_error(error,["u1", "u2", "u3"])
errate=0#0,0.001,0.005,0.01,0.015,0.02,0.025,0.03,0.04,0.045,0.05
error = depolarizing_error(errate, 2)
noise_model.add_all_qubit_quantum_error(error,'cx')
sim_noise = QasmSimulator(noise_model=noise_model)

# sim = QasmSimulator()
I  = np.array([[ 1, 0],
               [ 0, 1]])
Sx = np.array([[ 0, 1],
               [ 1, 0]])
Sy = np.array([[ 0,-1j],
               [1j, 0]])
Sz = np.array([[ 1, 0],
               [ 0,-1]])

#%%
# Heisenberg model
def Heisenberg(N,J_x,J_y,J_z):
    J = [J_x,J_y,J_z]
    pp = 0
    H = np.zeros(shape=(2**N,2**N))
    for p in ['X','Y','Z']:
        pauli_p = [p*2]+list(itertools.repeat('I',N-2))
        add_p = [p]+list(itertools.repeat('I',N-2))+[p]
        comb_p = list(set(itertools.permutations(pauli_p,N-1)))
        comb_p.append(list(add_p))
        H_p = np.zeros(shape=(2**N,2**N))
        for i in range(len(comb_p)):
            pauli_p = ''
            for j in range(len(comb_p[i])):
                pauli_p = pauli_p+comb_p[i][j]
            H_p = H_p+Pauli(pauli_p).to_matrix()
        H = H+J[pp]*H_p
        pp = pp+1
    
    pauli_z = ['Z']+list(itertools.repeat('I',N-1))
    comb_z = list(set(itertools.permutations(pauli_z,N)))   
    H_z = np.zeros(shape=(2**N,2**N))
    for i in range(len(comb_z)):
        pauli_z = ''
        for j in range(len(comb_z[i])):
            pauli_z = pauli_z+comb_z[i][j]
        H_z = H_z+Pauli(pauli_z).to_matrix()
    
    H_fin = -0.5*(H+H_z)
    return H_fin

# spin glass
def spin(N,seed):
    random.seed(seed)
    J = []
    for pp in range(int(N*(N-1)*1.5)):
        J.append(random.uniform(-1,1))
    t=0
    H_p = np.zeros(shape=(2**N,2**N))
    for p in ['X','Y','Z']:
        pauli_p = [p]+[p]+list(itertools.repeat('I',N-2))
        comb_p = list(set(itertools.permutations(pauli_p,N)))
        comb_p.sort()
        for i in range(len(comb_p)):
            pauli_p = ''
            for j in range(len(comb_p[i])):
                pauli_p = pauli_p+comb_p[i][j]
            H_p = H_p+J[i+t*len(comb_p)]*Pauli(pauli_p).to_matrix()
        t=t+1
    return H_p

# molecular
def LiH(dist):
    molecule = Molecule(
        geometry=[["li", [0, 0, .0]], ["H", [dist, 0, .0]]],
        charge=0, multiplicity=1,
    )
    
    driver = ElectronicStructureMoleculeDriver(
        molecule, basis="sto-3g", driver_type=ElectronicStructureDriverType.PYSCF,
    )
    # es_problem = ElectronicStructureProblem(driver,[ActiveSpaceTransformer(2,6)])
    es_problem = ElectronicStructureProblem(driver)
    second_q_op = es_problem.second_q_ops()
    # TQR=TwoQubitReduction(es_problem.num_particles)
    # qubit_converter = QubitConverter(mapper=ParityMapper())#,two_qubit_reduction=True,)
    qubit_converter = QubitConverter(mapper=JordanWignerMapper())
    qubitOp = qubit_converter.convert(second_q_op['ElectronicEnergy'])
    # qubitOp = TQR.convert(qubitOp)
    H=qubitOp.to_spmatrix()
    return H,qubitOp

# Heisenberg model 3D
def Heisenberg3D(L1,L2,L3,J_x,J_y,J_z):
    N = L1*L2*L3
    J = [J_x,J_y,J_z]
    pp = 0
    H = np.zeros(shape=(2**N,2**N))
    for p in ['X','Y','Z']:
        H_p1 = np.zeros(shape=(2**N,2**N))
        H_p2 = np.zeros(shape=(2**N,2**N))
        H_p3 = np.zeros(shape=(2**N,2**N))
        for i in range(N):
            if i%L1<L1-1:
                a=1
                pauli_p1 = ['I'*i]+[p*2]+['I'*(N-1-(i+a))]
                pauli_pp1 = ''
                for j in range(len(pauli_p1)):
                    for k in range(len(pauli_p1[j])):
                        pauli_pp1 = pauli_pp1+pauli_p1[j][k]
                H_p1 = H_p1+Pauli(pauli_pp1).to_matrix()
            if i%(L1*L2)<L1*L2-L1:
                a=L1
                pauli_p2 = ['I'*i]+[p]+['I'*(a-1)]+[p]+['I'*(N-1-(i+a))]
                pauli_pp2 = ''
                for j in range(len(pauli_p2)):
                    for k in range(len(pauli_p2[j])):
                        pauli_pp2 = pauli_pp2+pauli_p2[j][k]
                H_p2 = H_p2+Pauli(pauli_pp2).to_matrix()
            if i%(L1*L2*L3)<L1*L2*L3-L1*L2:
                a=L1*L2
                pauli_p3 = ['I'*i]+[p]+['I'*(a-1)]+[p]+['I'*(N-1-(i+a))]
                pauli_pp3 = ''
                for j in range(len(pauli_p3)):
                    for k in range(len(pauli_p3[j])):
                        pauli_pp3 = pauli_pp3+pauli_p3[j][k]
                H_p3 = H_p3+Pauli(pauli_pp3).to_matrix()
        H_p = H_p1+H_p2+H_p3
        H = H+J[pp]*H_p
        pp=pp+1
    pauli_z = ['Z']+list(itertools.repeat('I',N-1))
    comb_z = list(set(itertools.permutations(pauli_z,N)))   
    H_z = np.zeros(shape=(2**N,2**N))
    for i in range(len(comb_z)):
        pauli_z = ''
        for j in range(len(comb_z[i])):
            pauli_z = pauli_z+comb_z[i][j]
        H_z = H_z+Pauli(pauli_z).to_matrix()    
    H_fin = -0.5*(H+H_z)
    return H_fin

#%%
def get_qubit_op(dist):
    driver = PySCFDriver(atom="H .0 .0 .0; H .0 .0 " + str(dist)#+";H .0 .0 "+str(dist*2)
                          # +";H .0 .0 "+str(dist*3)#+";H .0 .0 "+str(dist*4)#+";H .0 .0 "+str(dist*5)
                         , unit=DistanceUnit.ANGSTROM
                        , spin=0,charge=0, basis='sto3g')
    molecule = driver.run()
    repulsion_energy = molecule.nuclear_repulsion_energy
    num_particles = molecule.num_alpha + molecule.num_beta
    num_spin_orbitals = molecule.num_orbitals * 2
    #ferOp = FermionicOperator(h1=molecule.one_body_integrals, h2=molecule.two_body_integrals)
    #qubitOp = ferOp.mapping(map_type=map_type, threshold=0.00000001)
    es_problem = ElectronicStructureProblem(driver)
    second_q_op = es_problem.second_q_ops()
    qubit_converter = QubitConverter(JordanWignerMapper())
    qubitOp = qubit_converter.convert(second_q_op[0])
    #g = groupedFermionicOperator(ferOp, num_particles)
    #qubitOp = g.to_paulis()
    shift =  repulsion_energy
    return qubitOp, num_particles, num_spin_orbitals, shift

def makewave(wavefunction,dele,name):
    #--------------4q,c0
    # n = wavefunction.num_qubits
    # param = ParameterVector(name,int((4*n-4)*3))
    # t=0
    # for depth in range(1):
    #     for i in range(n):
    #         wavefunction.rx(param[t], i)
    #         t+=1
    #     wavefunction.ryy(param[t],1, 0)
    #     t+=1
    #     wavefunction.ryy(param[t],2, 1)
    #     t+=1
    #     wavefunction.ryy(param[t],3, 2)
    #     t+=1
    #     for i in range(n):
    #         wavefunction.rz(param[t], i)
    #         t+=1
    # -------------------------4q,c1
    # n=wavefunction.num_qubits
    # param = ParameterVector(name,int(3*n*(n-1)+6*n))
    # t=0
    # for depth in range(1):
    #     for i in range(n):
    #         wavefunction.ry(param[t],i)
    #         t+=1
    #     # for i in range(n):
    #     #     wavefunction.rz(param[t],i)
    #     #     t+=1
    #     for i in range(n):
    #         for j in range(i,n):
    #             if i!=j:
    #                 wavefunction.cry(param[t],i,j%n)
    #                 t+=1
     #------------------4q,c11->c0 in noiseless_h1
    n = wavefunction.num_qubits
    param = ParameterVector(name,int((4*n-4)*3))
    t=0
    for depth in range(1):
        for i in range(n):
            if t not in dele:
                wavefunction.ry(param[t], i)
            t+=1
            wavefunction.rz(param[t], i)
            t+=1
        for j in range(int(n/2)):
            wavefunction.cnot(2*j+1,2*j)
        for i in range(n):
            if i>0 and i<n-1:
                if t not in dele:
                    wavefunction.ry(param[t], i)
                t+=1
                wavefunction.rz(param[t], i)
                t+=1
        for j in range(int(n/2)):
            if j>0 and j<int(n/2):
                wavefunction.cnot(2*j,2*j-1)
        wavefunction.barrier()
    #-------------------------------c2
    # n = wavefunction.num_qubits
    # param = ParameterVector(name,int((4*n-4)*3))
    # t=0
    # for depth in range(1):
    #     for i in range(n):
    #         wavefunction.rx(param[t], i)
    #         t+=1
    #     for i in range(n-1):
    #         wavefunction.ryy(param[t],i+1, i)
    #         t+=1
        # wavefunction.ryy(param[t],n-1, 0)
        # t+=1
        # for i in range(n):
        #     wavefunction.rz(param[t], i)
        #     t+=1
    return wavefunction
# H or H_p
def L(params,wavefunction):
    a={}
    t=0
    for i in wavefunction.parameters:
        a[i]=params[t]
        t+=1
        
    qc = wavefunction.assign_parameters(a)
    # qc.snapshot(label='final',snapshot_type='statevector')
    qc.save_statevector()
    qc.measure_all()
    circ_noise = transpile(qc, sim_noise)
    noise_result = sim_noise.run(circ_noise, shots=1).result()
    # u=noise_result.data(0)['snapshots']['statevector']['final'][0]
    u = noise_result.get_statevector()
    # counts = noise_result.get_counts(qc)
    # u=np.zeros(2**wavefunction.num_qubits)
    # for i in list(counts):
    #     u[int(i,2)]=counts[i]
    # u/=sum(u)
    # u=np.sqrt(u)
    # print((v.conj().dot(Hp.dot(v)).real)+shift)
    # E3.append(u.conj().dot(Hp.dot(u)).real)
    return u.conj().dot(Hp.dot(u)).real
    # return -state_fidelity(u,ext)
def dtheta(params,wavefunction,H):
    N=wavefunction.num_parameters
    A=np.zeros([N,N],dtype=np.complex128)
    C=np.zeros(N,dtype=np.complex128)
    phi=Lv(params,wavefunction)
    dpdt=[]
    cp=1/2
    a=np.pi/2
    for i in range(len(params)):
        ptmp1=params.copy()
        ptmp2=params.copy()
        ptmp1[i]+=a
        ptmp2[i]-=a    
        dp=cp*(Lv(ptmp1,wavefunction)-Lv(ptmp2,wavefunction))
        dpdt.append(dp)
    for i in range(len(params)):
        for j in range(len(params)):
            A[i,j]=(dpdt[i].conj().dot(dpdt[j])).real+dpdt[i].conj().dot(phi)*dpdt[j].conj().dot(phi)
    for i in range(len(params)):
        shape=np.size(dpdt[i])
        # phi=Lv(params,wavefunction)
        C[i]=(dpdt[i].conj().reshape(1,shape).dot((H.dot(phi)).reshape(shape,1))).real
    dx=np.linalg.pinv(A.real).dot(-C)
    return dx.real

def Lv(params,wavefunction):
    a={}
    t=0
    for i in wavefunction.parameters:
        a[i]=params[t]
        t+=1
    qc = wavefunction.assign_parameters(a)
    #qc.snapshot_density_matrix('final')
    #qp.save_density_matrix(qc,label='final')
    #qc.snapshot()
    qc.save_statevector()
    # qc.snapshot(label='final',snapshot_type='statevector')
    qc.measure_all()
    # U=[]
    # for i in range(100):
    circ_noise = transpile(qc, sim_noise)
    noise_result = sim_noise.run(circ_noise,shots=1).result()
    u=noise_result.get_statevector()
    # U.append(u)
    # u=sum(U)/10
    # counts = noise_result.get_counts(qc)
    # u=np.zeros(2**wavefunction.num_qubits)
    # for i in list(counts):
    #     u[int(i,2)]=counts[i]
    # u/=sum(u)
    # u=np.sqrt(u)
    return np.array(u)

def commutator(A,B):
    return A.dot(B)-B.dot(A)

def anticommutator(A,B):
    return A.dot(B)+B.dot(A)

def label2Pauli(s): # can be imported from groupedFermionicOperator.py
    """
    Convert a Pauli string into Pauli object. 
    Note that the qubits are labelled in descending order: 'IXYZ' represents I_3 X_2 Y_1 Z_0
    
    Args: 
        s (str) : string representation of a Pauli term
    
    Returns:
        qiskit.quantum_info.Pauli: Pauli object of s
    """
    
    xs = []
    zs = []
    label2XZ = {'I': (0, 0), 'X': (1, 0), 'Y': (1, 1), 'Z': (0, 1)}
    for c in s[::-1]:
        x, z = label2XZ[c]
        xs.append(x)
        zs.append(z)
    return Pauli(z = zs, x = xs)



def Tmax(u):
    v=u.copy()
    for i in range(len(v)):
        v[i]=v[i]%(4*np.pi)
    # for i in range(len(v)):
    #     if abs(v[i]-4*np.pi)<abs(v[i]):
    #         v[i]=v[i]-4*np.pi
    return v

def varL(params,wavefunction):
    a={}
    t=0
    for i in wavefunction.parameters:
        a[i]=params[t]
        t+=1
        
    qc = wavefunction.assign_parameters(a)
    qc.snapshot(label='final',snapshot_type='statevector')
    qc.measure_all()
    circ_noise = transpile(qc, sim_noise)
    noise_result = sim_noise.run(circ_noise, shots=1).result()
    u=noise_result.data(0)['snapshots']['statevector']['final'][0]
    return (u.conj().dot(H2.dot(u))-u.conj().dot(Hp.dot(u))**2).real

def sf(v,u,w):
    sf_v = []
    us=np.argsort(u)
    for i in us:
        sf_v.append(state_fidelity(v, w[:,i]))
        #print(state_fidelity(v, w[:,i]))
    return sf_v
#%%
def et(E,step,a):
    EE = []
    for i in E:
        #EE.append(Tmax(i))
        EE.append(i)
    X_H = np.array(EE)
    df_e2 = pd.DataFrame(X_H)
    return df_e2.to_excel('NT_00no_'+str(step)+'_EE'+str(a)+'h1n4'+'.xlsx')
#'C11_'+str(step)+'_EE'+str(a)+'.xlsx';015no: 1qubit0,2qubit0.015
# '00no_'+str(step)+'_EE'+str(a)+'h1C1'+'.xlsx'
# '00no_'+str(step)+'_EE'+str(a)+'h1n12'+'.xlsx',scaling qubit n=12,8,4; c11, h1
# hopkins test
def hopkins(X):
    d = X.shape[1]
    #d = len(vars) # columns
    n = len(X) # rows
    m = int(0.1 * n)
    nbrs = NearestNeighbors(n_neighbors=1).fit(X.values)
 
    rand_X = sample(range(0, n, 1), m)
 
    ujd = []
    wjd = []
    for j in range(0, m):
        u_dist, _ = nbrs.kneighbors(uniform(np.amin(X,axis=0),np.amax(X,axis=0),d).reshape(1, -1), 2, return_distance=True)
        ujd.append(u_dist[0][1])
        w_dist, _ = nbrs.kneighbors(X.iloc[rand_X[j]].values.reshape(1, -1), 2, return_distance=True)
        wjd.append(w_dist[0][1])
 
    H = sum(ujd) / (sum(ujd) + sum(wjd))
    if isnan(H):
        print(ujd, wjd)
        H = 0
    return H
def normalization(data):
    a = np.size(data,0)
    b = np.size(data,1)
    data1 = np.zeros(shape=(a,b))
    data2 = np.zeros(shape=(a,b))
    for i in range(a):
        for j in range(b):
            data1[i,j] = (np.exp(1j*data[i,j])).real
            data2[i,j] = (np.exp(1j*data[i,j])).imag
    return np.hstack((data1,data2))

#%% initial
roop=25#120,5,10,15,20,25
n=4 #4, 8, 12, 6, 10
wavefunction = QuantumCircuit(n)
for i in range(n):
    wavefunction.h(i)


dele=[]
wavefunction = makewave(wavefunction, dele,1)
#wavefunction.draw('mpl')
N=wavefunction.num_parameters
# Hp=Sz.copy()
# Hp=qubitOp.to_opflow().to_matrix()
Hp=Heisenberg(n, 0.5, 0.5, 0.6) #h1:0.5,0.5,0.6; h0:0.9,0.3,0.9
u,w=np.linalg.eigh(Hp)
u,w = sp.sparse.linalg.eigs(Hp,k=15,which='SR')
uu = sorted(set(np.around(u.real,5)))[0:5]
# uu = sorted(set(np.around(u.real,5)))

# Hp = spin(n,1) #h2:4,1
# u,w=np.linalg.eigh(Hp)

# dist = 1
# Hp,Pauli_Op = LiH(dist) # h3:12qubit
# u,w = sp.sparse.linalg.eigsh(Hp)

# Hp=Heisenberg3D(2, 2, 2, 0.5, 0.5, 0.6)
# u,w = sp.sparse.linalg.eigs(Hp,k=15,which='SR')
# uu = sorted(set(np.around(u.real,5)))[0:5]

H2 = Hp.T.conjugate() * Hp
# H2=Hp.dot(Hp)
# cv=Lv(x0, wavefunction)

#%%
# le = int(np.around(max(u)-min(u),1)*10+10)
# le = 100
# uhist=[]
# Ho = (Hp-e*np.eye(2**n)).T.conjugate() * (Hp-e*np.eye(2**n))
# Uo = [L(xo,wavefunction)]
# for i in range(1000):
#     dxo = dtheta(xo, wavefunction, Ho)
#     xo+=(dxo)*dt
#     Uo.append(L(xo,wavefunction))
#     if abs(Uo[-1]-Uo[-2])<1e-3:
#             break
# s = 0
# ds = 20
# UN = []
# for i in range(le):
#     E.append(s)
#     # H=Ho*s*Hp
#     x0 = xo.copy()
#     U=[L(x0,wavefunction)]
#     ###########
#     for i in range(roop):
#         for j in range(int(s)):
#             dx0=dtheta(x0, wavefunction, -Hp)
#             # x0+=(dx0)*(dt/int(s))
#             x0 = x0*dt
#         # print(x0)
#         U.append(L(x0,wavefunction))
#         print(s,'\n Energy:',U[-1])
#         if abs(U[-1]-U[-2])<1e-2:
#             UN.append(U[-1])
#             break
#         v=Lv(x0, wavefunction)
#     E1.append(x0)
#     uhist.append(len(U))
#     s+=ds
#     # if len(U)<0.8*np.mean(uhist):
#     #     ds = np.around(ds/2,5)
#     # if len(U)>1.25*np.mean(uhist):
#     #     ds = np.around(2*ds,5)
#     if UN[-1]>max(u):
#         break

#%% stop by eigenvalue
# le = int(np.around(max(u)-min(u),1)*200)
for a in range(3):
    # E1=[]
    # E5=[]
    # E10=[]
    # E15=[]
    # E20=[]
    E25=[]
    E=[]
    #dt=2e-1 
    # dt = 5e-2
    dt=5e-2
    #e = np.around(min(u),3)-0.3*(max(u)-min(u))
    e = (np.around(min(u),3)-0.2*(max(u)-min(u))).real
    e = (np.around(min(uu)-0.2*(max(uu)-min(uu)),3)).real
    le = 600
    # uhist=[]
    UN = []
    fid=[]
    ind_fid=[]
    I = []
    # de = 0.05
    #de = np.around(max(u)-min(u),1)/(20*5)
    # de = (np.around((max(uu)-min(uu))/(20*5),5)).real
    de = (np.around((max(uu)-min(uu))/(20*8),5)).real
    xo=np.random.rand(N)*0.1
    for i in range(le):
        E.append(e)
        # H=(Hp-e*np.eye(2**n)).dot(Hp-e*np.eye(2**n))
        H = (Hp-e*np.eye(2**n)).T.conjugate().dot(Hp-e*np.eye(2**n))
        x0 = xo.copy()
        U=[L(x0,wavefunction)]
        ###########
        for j in range(roop):
            dx0=dtheta(x0, wavefunction, H)
            x0=(dx0)*dt+x0
            # print(x0)
            U.append(L(x0,wavefunction))
            F = Lv(x0,wavefunction)
            print(e,'\n Energy:',U[-1],
                  '\n fid:',np.round(max(sf(F,u,w))/sum(sf(F,u,w)),4),
                  '\n no:',np.argsort(sf(F,u,w))[::-1])
            # if abs(U[-1]-U[-2])<1e-2:
            #     UN.append(U[-1])
            #     fid.append(max(sf(F,u,w)))
            #     ind_fid.append(sf(F,u,w).index(max(sf(F,u,w))))
            #     I.append(i)
            #     break
            # if j==4:
            #     E5.append(x0)
            # if j==9:
            #     E10.append(x0)
            # if j==14:
            #     E15.append(x0)
            # if j==19:
            #     E20.append(x0)
            if j==roop-1:
                E25.append(x0)
                UN.append(U[-1])
                fid.append(max(sf(F,u,w)))
                ind_fid.append(sf(F,u,w).index(max(sf(F,u,w))))
            # v=Lv(x0, wavefunction)
        #E1.append(x0)
        # uhist.append(len(U))
        # if len(U)<0.8*uhist[-1] or np.var(UN[-5:])>0.1:
        #     de = np.around(0.2*de,3)+0.001
        # if len(U)>1.5*np.mean(uhist[-10:]) or np.var(UN[-10:])<0.01 :
        #     de = np.around(1.2*de,3)+0.001
        e+=de
        # if E[-1]>max(u)+0.3*(max(u)-min(u)):
        #     break
        if E[-1]>(max(uu)+0.1*(max(uu)-min(uu))).real:
            break 
        # if E[-1]>(max(uu)+0.2*(max(uu)-min(uu))).real:
        #     break 
    
    # E2=[]
    # for i in E1:
    #     E2.append(Tmax(i))
    # d=[]
    # for i in range(len(E1)-1):
    #     d.append(np.linalg.norm(E2[i]-E2[i+1]))
    # X_H = np.array(E2)
    # df_e2 = pd.DataFrame(X_H)
    # df_e2.to_excel('C11_30_e2'+str(a)+'.xlsx')
    ind_fid = pd.DataFrame(ind_fid)
    fid = pd.DataFrame(fid)
    # ind_fid.to_excel('upL4_00no_'+'ind_fid'+str(a)+'3D_h1n8'+'.xlsx')
    # fid.to_excel('upL4_00no_'+'fid'+str(a)+'3D_h1n8'+'.xlsx')
    ind_fid.to_excel('NT_00no_'+'ind_fid'+str(a)+'h1n4'+'.xlsx')
    fid.to_excel('NT_00no_'+'fid'+str(a)+'h1n4'+'.xlsx')
    
    # et(E5,5,a)
    # et(E10,10,a)
    #et(E15,15,a)
    #et(E20,20,a)
    et(E25,roop,a)
    
  
#%% stop by eigenvector
E1=[]
E=[]
e0 = np.around(u[-6],3)-0.01
e1 = np.around(u[-1],3)+0.01
UN = []
uhist=[]
# de = 0.05
de = (e1-e0)/40
e = e0
dt=0.08
# c=0
for i in range(40):
    c=0
    # xo=np.random.rand(N)*2*np.pi
    xo = np.array([2*np.pi*np.random.uniform() for i in range(N)])
    E.append(e)
    # H=(Hp-e*np.eye(2**n)).dot(Hp-e*np.eye(2**n))
    H = (Hp-e*np.eye(2**n)).T.conjugate().dot(Hp-e*np.eye(2**n))
    x0 = xo.copy()
    U=[Lv(x0,wavefunction)]
    ###########
    i_roop = 0
    ii = 0
    while i_roop<roop:
        dx0=dtheta(x0, wavefunction, H)
        x0+=(dx0)*dt
        # print(x0)
        U.append(Lv(x0,wavefunction))
        i_roop =i_roop+1
        print(i,e)
        print(i_roop,np.argsort(sf(U[-1],u,w))[-5:][::-1],max(sf(U[-1],u,w)))        
        if max(sf(U[-1],u,w))>0.5: #1: 0.5; 2: 0.35; 3: 0.3
            c+=1
        if c>2:
            UN.append(U[-1])
            E1.append(x0)
            break
        if i_roop>40:
            x0 = np.array([2*np.pi*np.random.uniform() for i in range(N)])
            i_roop = 0
            ii = ii+1
        if ii>2:
            uhist.append(i)
            break
        # v=Lv(x0, wavefunction)
    # E1.append(x0)
    e+=de

E2=[]
for i in E1:
    E2.append(Tmax(i))
    

#%% hopkins test
X_H = pd.read_excel('NT_00no_10_EE0h3C2.xlsx').iloc[:,-N:] #'C11_25_EE1.xlsx'

hopkins(X_H)

#%%
E = []
for i in range(np.size(X_H,0)):
    E.append(e)
    e = e+de
#%% KMeans
# X_H = pd.DataFrame(data)
# size_x = np.size(X_H,0)
# plt.scatter(X_H[:,0],X_H[:,2])
#model_km = KMeans(n_clusters=2**n)
X_H = pd.read_excel('NT_00no_25_EE0h1n4.xlsx').iloc[:,-N:]
data = np.array(X_H)
data = normalization(data)
X_H = pd.DataFrame(data)
# for i in range(np.size(X_H,1)):
#     data[:,i] = Tmax(data[:,i])
# X_H = pd.DataFrame(data)
clusters = 12

model_km = KMeans(n_clusters=clusters,n_init=50)
model_km.fit(X_H)
centers_km = model_km.cluster_centers_
classes_km = model_km.labels_

s_km = silhouette_score(X_H, classes_km)
print(s_km)

#%%
# y_km = ",".join(str(x) for x in classes_km)

# df_km = pd.DataFrame(X_H)
df_km = X_H
df_km.insert(0, 'class', classes_km)
# df_km.insert(0, 'energy', UN)
df_km.insert(0, 's', E)
ind = []
for i in range(clusters):
    if np.size(classes_km[classes_km==i],0)<15:
        ind+=(list(np.where(classes_km==i)[0]))
df_km = df_km.drop(ind)
df_km = df_km.reset_index(drop=True)
# X_H = df_km
# E_km = [ele for idx, ele in enumerate(E_km) if idx not in ind]

nc={}
j=0
nc[df_km['class'][0]]=j
for i in range(len(df_km['class'])):
    if df_km['class'][i] in nc.keys():
        df_km['class'][i]=nc[df_km['class'][i]]
    else:
        j+=1
        nc[df_km['class'][i]]=j
        df_km['class'][i]=j
        
sns.boxplot(x='class',y='s',data=df_km)
for i in range(np.size(u)):
    plt.axhline(y=u[i], color='r', linestyle=':')
        
#%% joint form
df_0 = df_km[['s','class']]
df_1 = df_km[['s','class']]
#%%
df_2 = df_km[['s','class']]
df_3 = df_km[['s','class']]
df_4 = df_km[['s','class']]
#%%
df_left = pd.merge(df_0, df_1, on='s')
df_right = pd.merge(df_2, df_3, on='s')
#%%
df_all = pd.merge(df_left, df_right, on='s')
#%%
df_km.to_excel('eigenproblem/den_h1_00no_25step_1.xlsx')
# df_0.to_excel('C11_15step.xlsx')
# 'eigenproblem/hd0.5_00no_2step_1.xlsx'
#%%
df_full = pd.read_excel('eigenproblem/NT_h1n4_00no_25step_0.xlsx')
# df_km.rename(columns={'class_mode':'class'},inplace=True)
#%% plot
plt.scatter(df_km['s'], df_km['class'])
for i in range(np.size(uu)):
    plt.axvline(uu[i],color='r',ls=':')
plt.xlabel('s')
plt.ylabel('class')


sns.boxplot(x='class',y='s',data=df_full)
for i in range(np.size(u)):
    plt.axhline(y=u[i], color='r', linestyle=':')
    
# error
uu = list(set(np.around(u,4)))
uu.sort()
error = np.zeros(9)
for i in range(9):
    mean = np.mean(df_full[df_full['class']==i]['s'])
    error[i] = abs(np.around(mean-uu[i],4))
np.mean(error)
np.var(error)

error_all = []
error_all.append(error)

error_all = np.array(error_all).T.tolist()

plt.plot(error_all)

df_full = pd.read_excel('eigenproblem/noiseless_h1.xlsx',sheet_name='NT_aligned')
df_full = df_full[df_full['circuit']=='c0']
median=np.zeros(9)
for i in range(9):
    median[i] = np.median(df_full[df_full['class']==i]['s'])


# parallel_coordinates(df_full,'class')
#%%
data = X_H.iloc[:,-12:]
fit = umap.UMAP(n_neighbors=200,min_dist=0.9,n_components=3,metric='euclidean')
umap_fit = fit.fit_transform(data);
fig = plt.figure()
ax = fig.add_subplot(projection='3d')
ax.scatter(umap_fit[:,0], umap_fit[:,1], umap_fit[:,2], c=classes_km, marker='o')

#standard_embedding = umap.UMAP(random_state=42).fit_transform(X_H.data)
#plt.scatter(standard_embedding[:, 0], standard_embedding[:, 1], c=X_H.target.astype(int), s=0.1, cmap='Spectral');
def draw_umap(n_neighbors=15, min_dist=0.1, n_components=2, metric='euclidean', title=''):
    fit = umap.UMAP(
        n_neighbors=n_neighbors,
        min_dist=min_dist,
        n_components=n_components,
        metric=metric
    )
    umap_fit = fit.fit_transform(data);
    fig = plt.figure()
    if n_components == 1:
        ax = fig.add_subplot(111)
        ax.scatter(umap_fit[:,0], range(len(umap_fit)), c=df_km['class'])
    if n_components == 2:
        ax = fig.add_subplot(111)
        ax.scatter(umap_fit[:,0], umap_fit[:,1], c=classes_km)
    if n_components == 3:
        ax = fig.add_subplot(111, projection='3d')
        ax.scatter(umap_fit[:,0], umap_fit[:,1], umap_fit[:,2], c=classes_km, s=100)
    plt.title(title, fontsize=18)

draw_umap(n_neighbors=10)
#%% t-sne
data=X_H.iloc[:,-12:]
data=data.to_numpy()
tsne = TSNE(n_components=3,perplexity=50)
X_tsne = tsne.fit_transform(data)
tsne.kl_divergence_

plt.scatter(x=X_tsne[:, 0], y=X_tsne[:, 1], c=classes_km)

fig = plt.figure()
ax = fig.add_subplot(projection='3d')
ax.scatter(X_tsne[:,0], X_tsne[:,1], X_tsne[:,2], c=classes_km, marker='o')


# rs=minimize(varL, centers_km[3], wavefunction)
# rs = minimize(L, centers_km[0], wavefunction)

#%% error analysis
# IQR
for c in range(np.max(df_full['class'])):
    Q1 = np.percentile(df_full[df_full['class']==c]['s'],25,interpolation = 'midpoint')
    Q3 = np.percentile(df_full[df_full['class']==c]['s'],75,interpolation = 'midpoint')
    IQR = Q3 - Q1
    # Upper bound
    upper = df_full[df_full['class']==c][df_full[df_full['class']==c]['s'] >= Q3+1.5*IQR].index
    # Lower bound
    lower = df_full[df_full['class']==c][df_full[df_full['class']==c]['s'] <= Q1-1.5*IQR].index
    # remove
    df_full.drop(upper, inplace = True)
    df_full.drop(lower, inplace = True)
    
sns.boxplot(x='class',y='s',data=df_full)
for i in range(np.size(uu)):
    plt.axhline(y=uu[i], color='r', linestyle=':')
#%%
df_full.to_excel('eigenproblem/NT_h1n4_00no_25step_0.xlsx')

#%% cluster by states
data = np.array(X_H)
index_e = [i for i in list(range(40)) if i not in uhist]
value_e = []
for ind in index_e:
    value_e.append((e0+ind*de)*1)

# normalized
def normalization(data):
    _range = np.max(data) - np.min(data)
    return (data - np.min(data)) / _range
data  = normalization(data)

# standardized
def standardization(data):
    mu = np.mean(data, axis=0)
    sigma = np.std(data, axis=0)
    return (data - mu) / sigma
data = standardization(data)

model_state = KMeans(n_clusters=5,n_init=50)
model_state.fit(data)
centers_state = model_state.cluster_centers_
classes_state = model_state.labels_

df_state = pd.DataFrame(data)
df_state.insert(0, 'class', classes_state)

plt.scatter(E, classes_state)

parallel_coordinates(df_state,'class')
df_state.boxplot()

# with pca
pca = PCA(n_components=1)
data_pca = pca.fit_transform(data)
# data_pca = pd.DataFrame(data_pca)
pca_km = KMeans(n_clusters=3)
pca_km.fit(data_pca)
centers_pca = pca_km.cluster_centers_
classes_pca = pca_km.labels_

df_pca = pd.DataFrame(data_pca)
df_pca.insert(0, 'class', classes_pca)

plt.scatter(value_e, classes_pca)
parallel_coordinates(df_pca,'class')
df_pca.boxplot()

# mean-shift
bandwidth = estimate_bandwidth(data, quantile=0.5, n_samples=500)

ms = MeanShift(bandwidth, bin_seeding=False)
ms.fit(data)
labels = ms.labels_
cluster_centers = ms.cluster_centers_
plt.scatter(E, labels)

labels_unique = np.unique(labels)
n_clusters_ = len(labels_unique)

# spectral cluster
sc = SpectralClustering(n_clusters=16, assign_labels='discretize', random_state=0).fit(data)
sc_classes = sc.labels_
plt.scatter(E, sc_classes)

# optics
optics_model = OPTICS(min_samples=5,metric = 'euclidean',min_cluster_size = 16).fit(data)
op_classes = optics_model.labels_
plt.scatter(E, op_classes)

#Birch
bir_model = Birch(n_clusters=7,threshold=0.2,branching_factor=40).fit(data)
bir_classes = bir_model.predict(data)
#plt.scatter(E, bir_classes)

df_km = pd.DataFrame(data)
df_km.insert(0, 'class', bir_classes)
# df_km.insert(0, 'energy', UN)
df_km.insert(0, 's', E)

sns.boxplot(x='class',y='s',data=df_km)
for i in range(np.size(u)):
    plt.axhline(y=u[i], color='r', linestyle=':')
    
#DBSCAN
dbs_model = DBSCAN(eps=12,min_samples=10,metric='euclidean').fit(data)
dbs_classes = dbs_model.labels_
#plt.scatter(E, dbs_classes)
df_km = pd.DataFrame(data)
df_km.insert(0, 'class', dbs_classes)
# df_km.insert(0, 'energy', UN)
df_km.insert(0, 's', E)

sns.boxplot(x='class',y='s',data=df_km)
for i in range(np.size(u)):
    plt.axhline(y=u[i], color='r', linestyle=':')
# Riemannian kmeans
data = X_H.values
#import geomstats.backend as gs
from geomstats.geometry.hypersphere import Hypersphere
from geomstats.learning.online_kmeans import OnlineKMeans
#from geomstats.geometry.grassmannian import GrassmannianCanonicalMetric

#manifold = Grassmannian(16,12)
#GrassmannianCanonicalMetric(manifold)


manifold = Hypersphere(N)

r_kmeans = OnlineKMeans(manifold,n_clusters=6)
#r_kmeans = RiemannianKMeans(manifold,6)
r_kmeans.fit(data)
re_classes = r_kmeans.labels_

df_km = pd.DataFrame(data)
df_km.insert(0, 'class', re_classes)
# df_km.insert(0, 'energy', UN)
df_km.insert(0, 's', E)

sns.boxplot(x='class',y='s',data=df_km)
for i in range(np.size(u)):
    plt.axhline(y=u[i], color='r', linestyle=':')




#%% summary
Z = pd.read_excel('eigenproblem/error_sum.xlsx')
X = [5,10,15,20,25]
Y = [0.005,0.010,0.015,0.020,0.025,0.030,0.035,0.040]
X, Y = np.meshgrid(X,Y)
plt.pcolor(X,Y,Z)
plt.imshow(Z, interpolation='bilinear')
plt.contourf(X, Y, Z)

#-------------
noiseless_h1 = pd.read_excel('eigenproblem/noiseless_h1.xlsx',sheet_name='NT_aligned')
plt.rc('font', size=18) 
sns.boxplot(x='class',y='s', hue='circuit', data=noiseless_h1)

for i in range(np.size(u)):
    plt.axhline(y=u[i], color='r', linestyle=':')

sns.stripplot(x='class',y='s', hue='circuit', data=noiseless_h1, color="orange", jitter=0.2, size=2.5)
plt.title("Boxplot with jitter", loc="left")

#-------------
h1c11_error = pd.read_excel('eigenproblem/h1c11_error.xlsx',header=None,names=['0.005','0.010','0.015','0.020','0.025','0.030','0.035','0.040','0.045','0.050'])
h1c1_error = pd.read_excel('eigenproblem/h1c1_error.xlsx',header=None,names=['0.005','0.010','0.015','0.020','0.025','0.030'])
h1c11_error.plot()
x_step = [5,10,15,20,25]

plt.rc('font', size=14) 
fig, axes = plt.subplots(3, 2, sharex=True, sharey=True, figsize=(14, 8))
axes[0, 0].plot(x_step,h1c11_error['0.005'],linestyle='-',label='circuit c0')
axes[0, 0].plot(x_step,h1c1_error['0.005'],linestyle=':',label='circuit c1')
axes[0, 0].set_title('noise=0.005')
axes[0, 1].plot(x_step,h1c11_error['0.010'],linestyle='-')
axes[0, 1].plot(x_step,h1c1_error['0.010'],linestyle=':')
axes[0, 1].set_title('noise=0.010')
axes[1, 0].plot(x_step,h1c11_error['0.015'],linestyle='-')
axes[1, 0].plot(x_step,h1c1_error['0.015'],linestyle=':')
axes[1, 0].set_title('noise=0.015')
axes[1, 1].plot(x_step,h1c11_error['0.020'],linestyle='-')
axes[1, 1].plot(x_step,h1c1_error['0.020'],linestyle=':')
axes[1, 1].set_title('noise=0.020')
axes[2, 0].plot(x_step,h1c11_error['0.025'],linestyle='-')
axes[2, 0].plot(x_step,h1c1_error['0.025'],linestyle=':')
axes[2, 0].set_title('noise=0.025')
axes[2, 1].plot(x_step,h1c11_error['0.030'],linestyle='-')
axes[2, 1].plot(x_step,h1c1_error['0.030'],linestyle=':')
axes[2, 1].set_title('noise=0.030')
fig.legend()
plt.xticks(x_step)
fig.text(0, 0.5, 'error', va='center', rotation='vertical', fontsize='x-large')
fig.text(0.518, 0.019, 'steps', va='center', ha='center', fontsize='x-large')
plt.tight_layout()


plt.subplots_adjust(wspace=0, hspace=0)
plt.show()

#%% plug the median into the model
initial_para = pd.read_excel('eigenproblem/VQE_para_median_NT_h1n4_00no_25step_0.xlsx',sheet_name='median_para')
init_para = initial_para.to_numpy()[:,2:]
E = initial_para.to_numpy()[:,0]
roop = 300
fid_list = []
ind_fid_list = []
UN = []
UN_r = []
fid_r=[]
ind_fid_r=[]
I = []
para=[]
para_r = []
for a in range(8):
    dt=1e-2
    fid=[]
    ind_fid=[]
    # uhist=[]
    xo = init_para[a,:]
    e = E[a]
    # H = (Hp-e*np.eye(2**n)).T.conjugate().dot(Hp-e*np.eye(2**n))
    Hpp = (Hp-e*np.eye(2**n))/(max(uu)+abs(e))
    H_inv=np.linalg.inv(Hpp)
    H = H_inv
    x0 = xo.copy()
    U=[L(x0,wavefunction)]
    ###########
    for j in range(roop):
        dx0=dtheta(x0, wavefunction, H)
        x0=(dx0)*dt+x0
        # print(x0)
        U.append(L(x0,wavefunction))
        F = Lv(x0,wavefunction)
        fid.append(max(sf(F,u,w)))
        ind_fid.append(sf(F,u,w).index(max(sf(F,u,w))))
        if j%10==0:
            print(a,j,'\n Energy:',U[-1],
                  '\n fid:',np.round(max(sf(F,u,w))/sum(sf(F,u,w)),4),
                  '\n no:',np.argsort(sf(F,u,w))[::-1])           
        if abs(U[-1]-U[-2])<5e-4:
            UN.append(U[-1])
            para.append(x0)
            fid_list.append(fid)
            ind_fid_list.append(ind_fid)
            I.append(i)
            break
        if j==roop-1:
            para_r.append(x0)
            UN_r.append(U[-1])
            fid_r.append(max(sf(F,u,w)))
            ind_fid_r.append(sf(F,u,w).index(max(sf(F,u,w))))
        
#%% plot
from numpy.polynomial.polynomial import Polynomial
from pyqsp.angle_sequence import QuantumSignalProcessingPhases
import pennylane as qml
from scipy.linalg import expm
import pyqsp

for i in range(len(fid_list)):
    plt.plot(fid_list[i])

a=3
e=E[a]
H = (Hp-e*np.eye(2**n)).T.conjugate().dot(Hp-e*np.eye(2**n))
H=H/(max(uu)+abs(e))**2
Hpp = (Hp-e*np.eye(2**n))/(max(uu)+abs(e))
H_inv=np.linalg.inv(Hpp)
# kappa = np.linalg.cond(Hpp)
kappa=4
# test_u,test_w = sp.sparse.linalg.eigs(H,k=15,which='SR')
# test_uu=sorted(set(np.around(test_u.real,5)))


pcoefs, s = pyqsp.poly.PolyOneOverX().generate(kappa, return_coef=True, ensure_bounded=True, return_scale=True)
phi_pyqsp = pyqsp.angle_sequence.QuantumSignalProcessingPhases(pcoefs, signal_operator="Wx", tolerance=0.001)


# ang_seq = QuantumSignalProcessingPhases([0,0,1], signal_operator="Wz")
# polynomial_x2 = Polynomial([0,0,1])
# print("Polynomial object for x^2:", polynomial_x2)
wire_order = list(range(5))
# U_A = qml.matrix(qml.qsvt, wire_order=wire_order)(Hpp, ang_seq, wires=wire_order)
U_A = qml.matrix(qml.qsvt, wire_order=wire_order)(Hpp, phi_pyqsp, wires=wire_order)
qsvt_A = U_A[0:16,0:16].real
# plt.plot(qsvt_A, label="qsvt")

def A(t,qsvt_A): #sqare
    return expm(-qsvt_A* t)

# def A(t,qsvt_A): #inverse
#     return qsvt_A* t

def B(t,v_0,qsvt_A):
    Av = A(t,qsvt_A) @ v_0.reshape(-1,1)
    norm_Av = np.linalg.norm(Av)
    return Av / norm_Av if norm_Av != 0 else Av

def f(t,v_0,qsvt_A):
    Bv = B(t,v_0,qsvt_A)
    return np.dot(Bv.conj().T @ Hp, Bv).real
 

def po(t,v_0,qsvt_A):
    for i range(10):
        Av = A(t,qsvt_A) @ v_0.reshape(-1,1)
        norm_Av = np.linalg.norm(Av)
        An = Av / norm_Av
    return An
def power_iteration(A, num_iterations,v_0):
    b_k = v_0
    for _ in range(num_iterations):
        b_k1 = np.dot(A, b_k)
        b_k1_norm = np.linalg.norm(b_k1)
        b_k = b_k1 / b_k1_norm
    return b_k
u.conj().dot(Hp.dot(u)).real


   

# v_0 = Lv(init_para[a,:],wavefunction)
v_0 = 0.25*np.ones(16)
# v_0 = np.random.rand(16)
# f(10,qsvt_A)
# f(10,v_0,H_inv)
# e+(max(uu)+abs(e))/np.dot(v_0.conj().T @ H_inv, v_0)
evo = []
for i in range(30):
    u = power_iteration(H_inv, i,v_0)
    eny = u.conj().dot(Hp.dot(u)).real
    evo.append(eny)
plt.plot(evo)   

#%% plot
wire_order = list(range(5))
# v_0 = 0.25*np.ones(16)
evo_inv = np.zeros(shape=(30,8))
evo_qsvt = np.zeros(shape=(30,8))
ua = [-3.2, -2.0, -1.0, -0.93623, -0.0, 0.8, 1.2, 2.0]
for a in range(8):
    # a=1
    v_0 = Lv(init_para[a,:],wavefunction)
    e=E[a]    
    Hpp = (Hp-e*np.eye(2**n))/(max(uu)+abs(e))
    H_inv=np.linalg.inv(Hpp)    
    kappa=4
    # for ii in range(400):
    #     pcoefs, s = pyqsp.poly.PolyOneOverX().generate(kappa, return_coef=True, ensure_bounded=True, return_scale=True)
    #     phi_pyqsp = pyqsp.angle_sequence.QuantumSignalProcessingPhases(pcoefs, signal_operator="Wx", tolerance=0.001)    
    #     # U_A = qml.matrix(qml.qsvt, wire_order=wire_order)(Hpp, ang_seq, wires=wire_order)
    #     U_A = qml.matrix(qml.qsvt, wire_order=wire_order)(Hpp, phi_pyqsp, wires=wire_order)
    #     qsvt_A = U_A[0:16,0:16].real
    #     u = power_iteration(-qsvt_A, 20,v_0)        
    #     if abs(u.conj().dot(Hp.dot(u)).real-ua[a])<0.05:
    #         for i in range(30):
    #             u_qsvt = power_iteration(qsvt_A, i,v_0)
    #             evo_qsvt[i,a] = u_qsvt.conj().dot(Hp.dot(u_qsvt)).real
    #         break
    pcoefs, s = pyqsp.poly.PolyOneOverX().generate(kappa, return_coef=True, ensure_bounded=True, return_scale=True)
    phi_pyqsp = pyqsp.angle_sequence.QuantumSignalProcessingPhases(pcoefs, signal_operator="Wx", tolerance=0.001)    
    # U_A = qml.matrix(qml.qsvt, wire_order=wire_order)(Hpp, ang_seq, wires=wire_order)
    U_A = qml.matrix(qml.qsvt, wire_order=wire_order)(Hpp, phi_pyqsp, wires=wire_order)
    qsvt_A = U_A[0:16,0:16].real
    for i in range(30):
        u_inv = power_iteration(H_inv, i,v_0)
        u_qsvt = power_iteration(qsvt_A, i,v_0)
        evo_inv[i,a] = u_inv.conj().dot(Hp.dot(u_inv)).real
        evo_qsvt[i,a] = u_qsvt.conj().dot(Hp.dot(u_qsvt)).real
# plt.plot(evo_inv) 
plt.plot(evo_qsvt)      
for i in range(np.size(uu)):
    plt.axhline(y=uu[i], color='r', linestyle=':')
evo_qsvt[-1,:]

#%%
fig, axes = plt.subplots(2, 1, sharex=True, sharey=True, figsize=(8, 8))
# axes[0].plot(evo_inv,label='exact')
# axes[1].plot(evo_qsvt,label='qsvt')

colors = plt.cm.viridis(np.linspace(0, 1, 12))

for i in range(4):
    axes[0].plot(test_inv[:15,i], color=colors[3*i], linestyle='--')
    axes[0].plot(test_qsvt[:15,i], color=colors[3*i], linestyle='-')
for i in range(4):
    axes[0].axhline(y=uu[i], color='r', linestyle=':')
axes[0].set_title('Evolution from the uniform superposition state')

for i in range(3):
    axes[1].plot(test1_inv[:15,i], color=colors[3*i],linestyle='--')
    axes[1].plot(test1_qsvt[:15,i], color=colors[3*i],linestyle='-')
axes[1].plot(test1_inv[:15,3], color=colors[3*3],linestyle='--',label='exact inverse')
axes[1].plot(test1_qsvt[:15,3], color=colors[3*3],linestyle='-',label='QSVT')
for i in range(4):
    axes[1].axhline(y=uu[i], color='r', linestyle=':')
axes[1].set_title('Evolution from the prepared state')

axes[0].set_ylabel('s',fontsize=16)
axes[1].set_xlabel('step',fontsize=16)
axes[1].set_ylabel('s',fontsize=16)
axes[1].legend(bbox_to_anchor=(0.7,0.1))
#%% quantum power method
from qiskit import QuantumCircuit, execute, Aer, assemble

# v_0 = Lv(init_para[a,:],wavefunction)
v_0 = 0.25*np.ones(16)
# 定义矩阵A
t=0.01
A = expm(-1j * qsvt_H * t)

def create_power_method_circuit(A, initial_state, iterations,n):
    qc = QuantumCircuit(n, n)
    qc.initialize(initial_state, range(n))
    for _ in range(iterations):
        qc.unitary(A, range(n), label='A')
    qc.save_statevector('final_state')
    return qc

iterations = 10
qc = create_power_method_circuit(A, v_0, iterations,n)

simulator = AerSimulator()
compiled_circuit = transpile(qc, simulator)
qobj = assemble(compiled_circuit)
result = simulator.run(qobj).result()

# Get the statevector
statevector = result.data()['final_state']
u=statevector.data
u.conj().dot(Hp.dot(u)).real











