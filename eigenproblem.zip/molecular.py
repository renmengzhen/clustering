#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Nov  5 02:27:05 2023

@author: Mengzhen
"""
import matplotlib.pyplot as plt
import numpy as np
import itertools
import pandas as pd
from pandas.plotting import parallel_coordinates
from random import sample
from numpy.random import uniform
from math import isnan
import random

from qiskit import transpile
from qiskit.quantum_info import Pauli, Operator, state_fidelity
from qiskit.circuit import QuantumCircuit, ParameterVector, Parameter
#from qiskit.providers.aer.noise import NoiseModel,depolarizing_error, amplitude_damping_error
#from qiskit.providers.aer import AerSimulator,QasmSimulator,StatevectorSimulator
from qiskit_aer.noise import NoiseModel,depolarizing_error, amplitude_damping_error
from qiskit_aer import AerSimulator,QasmSimulator,StatevectorSimulator
# from qiskit_aer.library import save_statevector
from qiskit_nature.second_q.drivers import PySCFDriver
from qiskit_nature.units import DistanceUnit
from qiskit_nature.problems.second_quantization import ElectronicStructureProblem
from qiskit_nature.converters.second_quantization import QubitConverter
from qiskit_nature.mappers.second_quantization import JordanWignerMapper
#import qiskit.providers.aer.library as qp
from sklearn.cluster import KMeans, MeanShift, estimate_bandwidth, SpectralClustering, OPTICS, Birch
from sklearn.decomposition import PCA
from sklearn.metrics import silhouette_score
from sklearn.neighbors import NearestNeighbors

import seaborn as sns

from qiskit_nature.drivers import UnitsType, Molecule
from qiskit_nature.second_q.drivers import MethodType
from qiskit_nature.drivers.second_quantization import (
    ElectronicStructureDriverType,
    ElectronicStructureMoleculeDriver,
)
from qiskit_nature.problems.second_quantization import ElectronicStructureProblem
from qiskit_nature.transformers.second_quantization.electronic import FreezeCoreTransformer, ActiveSpaceTransformer
from qiskit_nature.converters.second_quantization import QubitConverter
from qiskit_nature.mappers.second_quantization import JordanWignerMapper, BravyiKitaevMapper, ParityMapper
import scipy as sp
#%%
map_type='jordan_wigner'
# backend = StatevectorSimulator(method="statevector")
noise_model = NoiseModel()
errate=0#0
error = depolarizing_error(errate, 1)
noise_model.add_all_qubit_quantum_error(error,["u1", "u2", "u3"])
errate=0#0,0.001,0.005,0.01,0.015,0.02,0.025,0.03,0.04,0.045,0.05
error = depolarizing_error(errate, 2)
noise_model.add_all_qubit_quantum_error(error,'cx')
sim_noise = QasmSimulator(noise_model=noise_model)

# sim = QasmSimulator()
I  = np.array([[ 1, 0],
               [ 0, 1]])
Sx = np.array([[ 0, 1],
               [ 1, 0]])
Sy = np.array([[ 0,-1j],
               [1j, 0]])
Sz = np.array([[ 1, 0],
               [ 0,-1]])



#%%
# Heisenberg model
def Heisenberg(N,J_x,J_y,J_z):
    J = [J_x,J_y,J_z]
    pp = 0
    H = np.zeros(shape=(2**N,2**N))
    for p in ['X','Y','Z']:
        pauli_p = [p*2]+list(itertools.repeat('I',N-2))
        add_p = [p]+list(itertools.repeat('I',N-2))+[p]
        comb_p = list(set(itertools.permutations(pauli_p,N-1)))
        comb_p.append(list(add_p))
        H_p = np.zeros(shape=(2**N,2**N))
        for i in range(len(comb_p)):
            pauli_p = ''
            for j in range(len(comb_p[i])):
                pauli_p = pauli_p+comb_p[i][j]
            H_p = H_p+Pauli(pauli_p).to_matrix()
        H = H+J[pp]*H_p
        pp = pp+1
    
    pauli_z = ['Z']+list(itertools.repeat('I',N-1))
    comb_z = list(set(itertools.permutations(pauli_z,N)))   
    H_z = np.zeros(shape=(2**N,2**N))
    for i in range(len(comb_z)):
        pauli_z = ''
        for j in range(len(comb_z[i])):
            pauli_z = pauli_z+comb_z[i][j]
        H_z = H_z+Pauli(pauli_z).to_matrix()
    
    H_fin = -0.5*(H+H_z)
    return H_fin

# spin glass
def spin(N,seed):
    random.seed(seed)
    J = []
    for pp in range(int(N*(N-1)*1.5)):
        J.append(random.uniform(-1,1))
    t=0
    H_p = np.zeros(shape=(2**N,2**N))
    for p in ['X','Y','Z']:
        pauli_p = [p]+[p]+list(itertools.repeat('I',N-2))
        comb_p = list(set(itertools.permutations(pauli_p,N)))
        comb_p.sort()
        for i in range(len(comb_p)):
            pauli_p = ''
            for j in range(len(comb_p[i])):
                pauli_p = pauli_p+comb_p[i][j]
            H_p = H_p+J[i+t*len(comb_p)]*Pauli(pauli_p).to_matrix()
        t=t+1
    return H_p

# molecular
def LiH(dist):
    molecule = Molecule(
        geometry=[["li", [0, 0, .0]], ["H", [dist, 0, .0]]],
        charge=0, multiplicity=1,
    )
    
    # driver = ElectronicStructureMoleculeDriver(
    #     molecule, basis="sto-3g", driver_type=ElectronicStructureDriverType.PYSCF,
    # )
    # # es_problem = ElectronicStructureProblem(driver,[ActiveSpaceTransformer(2,6)])
    # es_problem = ElectronicStructureProblem(driver)
    driver = ElectronicStructureMoleculeDriver(
        molecule, basis="6-31g", driver_type=ElectronicStructureDriverType.PYSCF,
    )
    es_problem = ElectronicStructureProblem(driver,[ActiveSpaceTransformer(2,6)])
    second_q_op = es_problem.second_q_ops()
    # TQR=TwoQubitReduction(es_problem.num_particles)
    # qubit_converter = QubitConverter(mapper=ParityMapper())#,two_qubit_reduction=True,)
    qubit_converter = QubitConverter(mapper=JordanWignerMapper())
    qubitOp = qubit_converter.convert(second_q_op['ElectronicEnergy'])
    # qubitOp = TQR.convert(qubitOp)
    H=qubitOp.to_spmatrix()
    return H,qubitOp



#%%
def get_qubit_op(dist):
    driver = PySCFDriver(atom="H .0 .0 .0; H .0 .0 " + str(dist)#+";H .0 .0 "+str(dist*2)
                          # +";H .0 .0 "+str(dist*3)#+";H .0 .0 "+str(dist*4)#+";H .0 .0 "+str(dist*5)
                         , unit=DistanceUnit.ANGSTROM
                        , spin=0,charge=0, basis='sto3g')
    molecule = driver.run()
    repulsion_energy = molecule.nuclear_repulsion_energy
    num_particles = molecule.num_alpha + molecule.num_beta
    num_spin_orbitals = molecule.num_orbitals * 2
    #ferOp = FermionicOperator(h1=molecule.one_body_integrals, h2=molecule.two_body_integrals)
    #qubitOp = ferOp.mapping(map_type=map_type, threshold=0.00000001)
    es_problem = ElectronicStructureProblem(driver)
    second_q_op = es_problem.second_q_ops()
    qubit_converter = QubitConverter(JordanWignerMapper())
    qubitOp = qubit_converter.convert(second_q_op[0])
    #g = groupedFermionicOperator(ferOp, num_particles)
    #qubitOp = g.to_paulis()
    shift =  repulsion_energy
    return qubitOp, num_particles, num_spin_orbitals, shift

def makewave0(wavefunction,dele,name):
    n = wavefunction.num_qubits
    param = ParameterVector(name,int(2*n))
    t=0
    for depth in range(1):
        for i in range(n):
            wavefunction.ry(param[t], i)
            t+=1
        for j in range(int(n/2)):
            wavefunction.cnot(2*j+1,2*j)
        for i in range(n):
            if i>0 and i<n-1:
                wavefunction.ry(param[t], i)
                t+=1
        for j in range(int(n/2)):
            if j>0 and j<int(n/2):
                wavefunction.cnot(2*j,2*j-1)
    return wavefunction

def makeinitial(wavefunction,param):
    n = wavefunction.num_qubits
    t=0
    for depth in range(1):
        for i in range(n):
            wavefunction.ry(param[t], i)
            t+=1
        for j in range(int(n/2)):
            wavefunction.cnot(2*j+1,2*j)
        for i in range(n):
            if i>0 and i<n-1:
                wavefunction.ry(param[t], i)
                t+=1
        for j in range(int(n/2)):
            if j>0 and j<int(n/2):
                wavefunction.cnot(2*j,2*j-1)    
    return wavefunction

def makewave1(wavefunction,dele,name):
    n = wavefunction.num_qubits
    param = ParameterVector(name,int(4*n+1))
    t=0
    for depth in range(1):
        wavefunction.barrier()
        for i in range(n):
            wavefunction.ry(param[t], i)
            t+=1
        # for j in range(n-1):
        #     wavefunction.crx(param[t],j+1,j)
        #     t+=1
        # wavefunction.crx(param[t],0,n-1)
        # t+=1
        for j in range(n-1):
            wavefunction.cnot(j+1,j)
        wavefunction.cnot(0,n-1)
        wavefunction.barrier()
        for i in range(n):
            wavefunction.ry(param[t], i)
            t+=1
        # for j in range(n-1):
        #     wavefunction.crx(param[t],j,j+1)
        #     t+=1
        # wavefunction.crx(param[t],n-1,0)
        # t+=1
        for j in range(n-1):
            wavefunction.cnot(j,j+1)
        wavefunction.cnot(n-1,0)
    return wavefunction
# H or H_p
def L(params,wavefunction):
    a={}
    t=0
    for i in wavefunction.parameters:
        a[i]=params[t]
        t+=1
        
    qc = wavefunction.assign_parameters(a)
    # qc.snapshot(label='final',snapshot_type='statevector')
    qc.save_statevector()
    qc.measure_all()
    circ_noise = transpile(qc, sim_noise)
    noise_result = sim_noise.run(circ_noise, shots=1).result()
    # u=noise_result.data(0)['snapshots']['statevector']['final'][0]
    u = noise_result.get_statevector()
    # counts = noise_result.get_counts(qc)
    # u=np.zeros(2**wavefunction.num_qubits)
    # for i in list(counts):
    #     u[int(i,2)]=counts[i]
    # u/=sum(u)
    # u=np.sqrt(u)
    # print((v.conj().dot(Hp.dot(v)).real)+shift)
    # E3.append(u.conj().dot(Hp.dot(u)).real)
    return u.conj().dot(Hp.dot(u)).real
    # return -state_fidelity(u,ext)
def dtheta(params,wavefunction,H):
    N=wavefunction.num_parameters
    A=np.zeros([N,N],dtype=np.complex128)
    C=np.zeros(N,dtype=np.complex128)
    phi=Lv(params,wavefunction)
    dpdt=[]
    cp=1/2
    a=np.pi/2
    for i in range(len(params)):
        ptmp1=params.copy()
        ptmp2=params.copy()
        ptmp1[i]+=a
        ptmp2[i]-=a    
        dp=cp*(Lv(ptmp1,wavefunction)-Lv(ptmp2,wavefunction))
        dpdt.append(dp)
    for i in range(len(params)):
        for j in range(len(params)):
            A[i,j]=(dpdt[i].conj().dot(dpdt[j])).real+dpdt[i].conj().dot(phi)*dpdt[j].conj().dot(phi)
    for i in range(len(params)):
        shape=np.size(dpdt[i])
        # phi=Lv(params,wavefunction)
        C[i]=(dpdt[i].conj().reshape(1,shape).dot((H.dot(phi)).reshape(shape,1))).real
    dx=np.linalg.pinv(A.real).dot(-C)
    return dx.real

def Lv(params,wavefunction):
    a={}
    t=0
    for i in wavefunction.parameters:
        a[i]=params[t]
        t+=1
    qc = wavefunction.assign_parameters(a)
    #qc.snapshot_density_matrix('final')
    #qp.save_density_matrix(qc,label='final')
    #qc.snapshot()
    qc.save_statevector()
    # qc.snapshot(label='final',snapshot_type='statevector')
    qc.measure_all()
    # U=[]
    # for i in range(100):
    circ_noise = transpile(qc, sim_noise)
    noise_result = sim_noise.run(circ_noise,shots=1).result()
    u=noise_result.get_statevector()
    # U.append(u)
    # u=sum(U)/10
    # counts = noise_result.get_counts(qc)
    # u=np.zeros(2**wavefunction.num_qubits)
    # for i in list(counts):
    #     u[int(i,2)]=counts[i]
    # u/=sum(u)
    # u=np.sqrt(u)
    return np.array(u)

def commutator(A,B):
    return A.dot(B)-B.dot(A)

def anticommutator(A,B):
    return A.dot(B)+B.dot(A)

def label2Pauli(s): # can be imported from groupedFermionicOperator.py
    """
    Convert a Pauli string into Pauli object. 
    Note that the qubits are labelled in descending order: 'IXYZ' represents I_3 X_2 Y_1 Z_0
    
    Args: 
        s (str) : string representation of a Pauli term
    
    Returns:
        qiskit.quantum_info.Pauli: Pauli object of s
    """
    
    xs = []
    zs = []
    label2XZ = {'I': (0, 0), 'X': (1, 0), 'Y': (1, 1), 'Z': (0, 1)}
    for c in s[::-1]:
        x, z = label2XZ[c]
        xs.append(x)
        zs.append(z)
    return Pauli(z = zs, x = xs)



def Tmax(u):
    v=u.copy()
    for i in range(len(v)):
        v[i]=v[i]%(4*np.pi)
    # for i in range(len(v)):
    #     if abs(v[i]-4*np.pi)<abs(v[i]):
    #         v[i]=v[i]-4*np.pi
    return v

def varL(params,wavefunction):
    a={}
    t=0
    for i in wavefunction.parameters:
        a[i]=params[t]
        t+=1
        
    qc = wavefunction.assign_parameters(a)
    qc.snapshot(label='final',snapshot_type='statevector')
    qc.measure_all()
    circ_noise = transpile(qc, sim_noise)
    noise_result = sim_noise.run(circ_noise, shots=1).result()
    u=noise_result.data(0)['snapshots']['statevector']['final'][0]
    return (u.conj().dot(H2.dot(u))-u.conj().dot(Hp.dot(u))**2).real

def sf(v,u,w):
    sf_v = []
    us=np.argsort(u)
    for i in us:
        sf_v.append(state_fidelity(v, w[:,i]))
        #print(state_fidelity(v, w[:,i]))
    return sf_v
#%%
def et(E,step,a,dist):
    EE = []
    for i in E:
        #EE.append(Tmax(i))
        EE.append(i)
    X_H = np.array(EE)
    df_e2 = pd.DataFrame(X_H)
    return df_e2.to_excel('update00no_'+str(step)+'_EE'+str(a)+'hd'+str(dist)+'.xlsx')
#'C11_'+str(step)+'_EE'+str(a)+'.xlsx';015no: 1qubit0,2qubit0.015
# '00no_'+str(step)+'_EE'+str(a)+'h1C1'+'.xlsx'
# 'NTadd_00no_'+str(step)+'_EE'+str(a)+'hd'+str(dist)+'.xlsx'
# '00no_'+str(step)+'_EE'+str(a)+'hd'+str(dist)+'.xlsx'
# hopkins test
def hopkins(X):
    d = X.shape[1]
    #d = len(vars) # columns
    n = len(X) # rows
    m = int(0.1 * n)
    nbrs = NearestNeighbors(n_neighbors=1).fit(X.values)
 
    rand_X = sample(range(0, n, 1), m)
 
    ujd = []
    wjd = []
    for j in range(0, m):
        u_dist, _ = nbrs.kneighbors(uniform(np.amin(X,axis=0),np.amax(X,axis=0),d).reshape(1, -1), 2, return_distance=True)
        ujd.append(u_dist[0][1])
        w_dist, _ = nbrs.kneighbors(X.iloc[rand_X[j]].values.reshape(1, -1), 2, return_distance=True)
        wjd.append(w_dist[0][1])
 
    H = sum(ujd) / (sum(ujd) + sum(wjd))
    if isnan(H):
        print(ujd, wjd)
        H = 0
    return H

def normalization(data):
    a = np.size(data,0)
    b = np.size(data,1)
    data1 = np.zeros(shape=(a,b))
    data2 = np.zeros(shape=(a,b))
    for i in range(a):
        for j in range(b):
            data1[i,j] = (np.exp(1j*data[i,j])).real
            data2[i,j] = (np.exp(1j*data[i,j])).imag
    return np.hstack((data1,data2))
#%%
# uu = np.zeros(shape=(15,10))
# for d in range(10):
#     dist = np.around(0.5+0.3*d,1)
#     Hp,Pauli_Op = LiH(dist) # h3:12qubit
#     u,w = sp.sparse.linalg.eigs(Hp,k=15,which='SR')
#     uu[:,d] = sorted(np.around(u.real,5))
# p = np.zeros(shape=(5,10))
# for d in range(10):
#     p[:,d] = sorted(set(uu[:,d]))[0:5]
# plt.plot(p.T)
n=12 #4, 6, 8

dist = 1.1 #0.5, 0.8, 1.1, 1.4, 1.7, 2, 2.3, 2.6
Hp,Pauli_Op = LiH(dist) # h3:12qubit
u,w = sp.sparse.linalg.eigs(Hp,k=15,which='SR')
H2 = Hp.T.conjugate() * Hp

wavefunction = QuantumCircuit(n)
for i in range(n):
    wavefunction.h(i)

# dele=[]
# wavefunction = makewave0(wavefunction, dele,1)
# NY=wavefunction.num_parameters
# #wavefunction.draw('mpl')
# yo=np.random.rand(NY)*0.1

# dt0 = 2e-1
# U0=[L(yo,wavefunction)]
# e0=(np.around(u[1]+0.01*(max(u)-min(u)),3)).real
# H0=(Hp-e0*np.eye(2**n)).T.conjugate().dot(Hp-e0*np.eye(2**n))
# y0 = yo.copy()
# for i in range(200):
#     dy0=dtheta(y0, wavefunction, H0)
#     y0=(dy0)*dt0+y0
#     # print(x0)
#     U0.append(L(y0,wavefunction))
#     F0 = Lv(y0,wavefunction)
#     print(i,'\n Energy:',U0[-1],'\n fid:',max(sf(F0,u,w)),'\n no:',np.argsort(sf(F0,u,w))[::-1])
#     if abs(U0[-1]-U0[-2])<1e-4:
#         break

#%%
dele=[]
wavefunction = QuantumCircuit(n)
for i in range(n):
    wavefunction.h(i)
# wavefunction = makeinitial(wavefunction, y0)
wavefunction = makewave0(wavefunction, dele,2)
#wavefunction.draw('mpl')
N=wavefunction.num_parameters
#%% prior
X_prior = pd.read_excel('update00no_2_EE0hd1.4.xlsx').iloc[:,-N:]
class_prior = pd.read_excel('eigenproblem/up_hd1.4_00no_2step_0.xlsx')

Hp_prior,Pauli_Op_prior = LiH(1.4) # h3:12qubit
u_p,w_p = sp.sparse.linalg.eigs(Hp_prior,k=15,which='SR')
uu_p = sorted(set(np.around(u_p.real,5)))[0:5]
e = (np.around(min(uu_p)-0.2*(max(uu_p)-min(uu_p)),3)).real
de = (np.around((max(uu_p)-min(uu_p))/(20*5),5)).real
E = []
for i in range(np.size(X_prior,0)):
    E.append(e)
    e = e+de
X_prior.insert(0, 's', E)
X_prior = np.array(X_prior)

median = np.zeros(5)
for i in range(5):
    me = np.median(class_prior[class_prior['class']==i]['s'])
    median[i] = np.around(me,5)
median = sorted(median)

x0_prior = np.zeros(shape=(5,N+1))
for i in range(5):
    x0_prior[i,0] = median[i]
    ind = np.argmin(abs(X_prior[:,0]-median[i]))
    x0_prior[i,-N:] = X_prior[ind,-N:]


#%%
roop=100 #200
for d in range(8):
    dist = np.round(0.5+0.3*d,2)
    Hp,Pauli_Op = LiH(dist) # h3:12qubit
    u,w = sp.sparse.linalg.eigs(Hp,k=15,which='SR')
    uu = sorted(set(np.around(u.real,5)))[0:5]
    H2 = Hp.T.conjugate() * Hp
    for a in range(1):
        Estop=[]
        Eroop=[]
        E=[]
        dt=2e-1
        e = (np.around(min(uu)-0.2*(max(uu)-min(uu)),3)).real
        # e = (np.around(u[1]+0.4*(max(u)-u[1]),3)).real
        le = 500
        # uhist=[]
        Ustep = []
        I = []
        de = (np.around((max(uu)-min(uu))/(20*5),5)).real
        # de = (np.around((max(u)-u[1])/(15*8),5)).real
        xo=np.random.rand(N)*0.1
        for i in range(le):
            E.append(e)
            # H=(Hp-e*np.eye(2**n)).dot(Hp-e*np.eye(2**n))
            H = (Hp-e*np.eye(2**n)).T.conjugate().dot(Hp-e*np.eye(2**n))
            #x0=xo.copy()
            ind = np.argmin(abs(x0_prior[:,0]-e))
            x0 = x0_prior[ind,-N:]           
            U=[L(x0,wavefunction)]
            ###########
            for j in range(roop):
                dx0=dtheta(x0, wavefunction, H)
                x0=(dx0)*dt+x0
                # print(x0)
                U.append(L(x0,wavefunction))
                F = Lv(x0,wavefunction)
                print(e,'\n Energy:',U[-1],
                      '\n fid:',np.round(max(sf(F,u,w))/sum(sf(F,u,w)),3),',',np.round(max(sf(F,u,w)),2),
                      '\n no:',np.argsort(sf(F,u,w))[::-1])
                # print(e,'\n Energy:',U[-1],
                #       '\n fid:',np.round(max(sf(F,u,w)),5),
                #       '\n no:',np.argsort(sf(F,u,w))[::-1])
                if abs(U[-1]-U[-2])<1e-4:
                    I.append(e)
                    Ustep.append(j)
                    Estop.append(x0)
                    Eroop.append(x0)
                    break
                # if j==4:
                #     E5.append(x0)
                # if j==9:
                #     E10.append(x0)
                # if j==14:
                #     E15.append(x0)
                # if j==19:
                #     E20.append(x0)
                # if j==24:
                #     E25.append(x0)
                if j==roop-1:
                    Ustep.append(roop)
                    Eroop.append(x0)
                # v=Lv(x0, wavefunction)
            #E1.append(x0)
            # uhist.append(len(U))
            # if len(U)<0.8*uhist[-1] or np.var(UN[-5:])>0.1:
            #     de = np.around(0.2*de,3)+0.001
            # if len(U)>1.5*np.mean(uhist[-10:]) or np.var(UN[-10:])<0.01 :
            #     de = np.around(1.2*de,3)+0.001
            e+=de
            if E[-1]>(max(uu)+0.2*(max(uu)-min(uu))).real:
                break 
            # if E[-1]>(max(u)+0.2*(max(u)-u[1])).real:
            #     break 
        #et(E5,5,a,dist)
        #et(E10,10,a,dist)
        #et(E15,15,a)
        #et(E20,20,a)
        I = pd.DataFrame(I)
        Ustep = pd.DataFrame(Ustep)
        I.to_excel('up00no_'+'I'+str(a)+'hd'+str(dist)+'.xlsx')
        Ustep.to_excel('up00no_'+'Ustep'+str(a)+'hd'+str(dist)+'.xlsx')
        et(Estop,1,a,dist)
        et(Eroop,2,a,dist)
#%% hopkins test
X_H = pd.read_excel('NT_00no_2_EE1hd1.xlsx').iloc[:,-N:] #'C11_25_EE1.xlsx'
hopkins(X_H)

#%% KMeans
# X_H = pd.DataFrame(data)
# size_x = np.size(X_H,0)
# plt.scatter(X_H[:,0],X_H[:,2])
#model_km = KMeans(n_clusters=2**n)
X_H = pd.read_excel('update00no_2_EE0hd1.1.xlsx').iloc[:,-N:]
data = np.array(X_H)
data = normalization(data)
X_H = pd.DataFrame(data)
#hopkins(X_H)
# for i in range(np.size(X_H,1)):
#     data[:,i] = Tmax(data[:,i])
# X_H = pd.DataFrame(data)
clusters =5

model_km = KMeans(n_clusters=clusters,n_init=50)
model_km.fit(X_H)
centers_km = model_km.cluster_centers_
classes_km = model_km.labels_

s_km = silhouette_score(X_H, classes_km)
print(s_km)

#%%
# y_km = ",".join(str(x) for x in classes_km)

# df_km = pd.DataFrame(X_H)
df_km = X_H
df_km.insert(0, 'class', classes_km)
# df_km.insert(0, 'energy', UN)
df_km.insert(0, 's', E)
ind = []
for i in range(clusters):
    if np.size(classes_km[classes_km==i],0)<5:
        ind+=(list(np.where(classes_km==i)[0]))
df_km = df_km.drop(ind)
df_km = df_km.reset_index(drop=True)
# X_H = df_km
# E_km = [ele for idx, ele in enumerate(E_km) if idx not in ind]

nc={}
j=0
nc[df_km['class'][0]]=j
for i in range(len(df_km['class'])):
    if df_km['class'][i] in nc.keys():
        df_km['class'][i]=nc[df_km['class'][i]]
    else:
        j+=1
        nc[df_km['class'][i]]=j
        df_km['class'][i]=j
        
sns.boxplot(x='class',y='s',data=df_km)
for i in range(np.size(u)):
    plt.axhline(y=u[i], color='r', linestyle=':')

#%%
df_full = pd.read_excel('eigenproblem/up_hd1.1_00no_2step_0.xlsx')
#%%
sns.boxplot(x='class',y='s',data=df_full)
for i in range(np.size(u)):
    plt.axhline(y=u[i], color='r', linestyle=':')

median = np.zeros(9)
for i in range(5):
    me = np.median(df_km[df_km['class']==i]['s'])
    median[i] = np.around(me,5)

#%%
df_exact = pd.read_excel('eigenproblem/molecular_energy.xlsx',sheet_name='exact')
df_estimated = pd.read_excel('eigenproblem/molecular_energy.xlsx',sheet_name='estimated_update')  
d = [0.5,0.8,1.1,1.4,1.7,2,2.3]

# interpolate
d_new = np.linspace(0.5, 2.3,100)
f1 = sp.interpolate.interp1d(d,df_exact['lambda_1'],kind='quadratic')
f2 = sp.interpolate.interp1d(d,df_exact['lambda_2'],kind='quadratic')
f3 = sp.interpolate.interp1d(d,df_exact['lambda_3'],kind='quadratic')

y1 = f1(d_new)
y2 = f2(d_new)
y3 = f3(d_new)
# error
error = np.zeros(shape=(7,3))
error[:,0]=abs(df_exact['lambda_1']-df_estimated['lambda_1'])
error[:,1]=abs(df_exact['lambda_2']-df_estimated['lambda_2'])
error[:,2]=abs(df_exact['lambda_3']-df_estimated['lambda_3'])

# RAD
RAD = np.zeros(shape=(7,3))
RAD[:,0]=abs(df_exact['lambda_1']-df_estimated['lambda_1'])/abs(df_estimated['lambda_1'])
RAD[:,1]=abs(df_exact['lambda_2']-df_estimated['lambda_2'])/abs(df_estimated['lambda_2'])
RAD[:,2]=abs(df_exact['lambda_3']-df_estimated['lambda_3'])/abs(df_estimated['lambda_3'])
np.mean(RAD)

# def mse(records_real, records_predict):
#     if len(records_real) == len(records_predict):
#         return sum([(x - y) ** 2 for x, y in zip(records_real, records_predict)]) / len(records_real)
# mse(df_exact['lambda_1'],df_estimated['lambda_1'])

# plot
plt.rc('font', size=22)
plt.plot(d_new,y1,'r:',label='ground state')
#plt.scatter(d,df_estimated['lambda_1'],color='r')
plt.errorbar(d,df_estimated['lambda_1'], yerr=error[:,0], fmt='o', color='r',
             ecolor='gray', elinewidth=3, capsize=0)

plt.plot(d_new,y2,'g:',label='1st exacted state')
plt.errorbar(d,df_estimated['lambda_2'], yerr=error[:,1], fmt='o', color='g',
             ecolor='gray', elinewidth=3, capsize=0)

plt.plot(d_new,y3,'b:',label='2nd exacted state')
plt.errorbar(d,df_estimated['lambda_3'], yerr=error[:,2], fmt='o', color='b',
             ecolor='gray', elinewidth=3, capsize=0)

plt.xticks(d)
plt.xlabel('internuclear separation')
plt.ylabel('energy')
plt.grid()
plt.legend()
