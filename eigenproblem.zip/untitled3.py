#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon May 22 06:08:21 2023

@author: Mengzhen
"""
#%%
data_e1 = E2
data_fid1 = fid

data_e2 = E2
data_fid2 = fid

data_e = [(a+b)*0.5 for a,b in zip(data_e1,data_e2)]
data_fid = [(a+b)*0.5 for a,b in zip(data_fid1,data_fid2)]

E2 = data_e1
#%%
X_H1 = np.array(X_H[0:145])
model_km = KMeans(n_clusters=2,n_init=50)
model_km.fit(X_H1)
centers_km = model_km.cluster_centers_
classes_km = model_km.labels_

s_km1 = silhouette_score(X_H1, classes_km)
classes_km1 = classes_km
print(s_km1)
#
X_H2 = np.array(X_H[145:302])
model_km = KMeans(n_clusters=3,n_init=50)
model_km.fit(X_H2)
centers_km = model_km.cluster_centers_
classes_km = model_km.labels_

s_km2 = silhouette_score(X_H2, classes_km)
classes_km2 = classes_km + 2
print(s_km2)
#
X_H3 = np.array(X_H[-147:])
model_km = KMeans(n_clusters=3,n_init=50)
model_km.fit(X_H3)
centers_km = model_km.cluster_centers_
classes_km = model_km.labels_

s_km3 = silhouette_score(X_H3, classes_km)
classes_km3 = classes_km + 5
print(s_km3)
#
X_H4 = np.array(X_H[-112:])
model_km = KMeans(n_clusters=4,n_init=50)
model_km.fit(X_H4)
centers_km = model_km.cluster_centers_
classes_km = model_km.labels_

s_km4 = silhouette_score(X_H4, classes_km)
classes_km4 = classes_km + 12
print(s_km4)
#
X_H5 = np.array(E2[180:])
model_km = KMeans(n_clusters=2,n_init=50)
model_km.fit(X_H5)
centers_km = model_km.cluster_centers_
classes_km = model_km.labels_

s_km5 = silhouette_score(X_H5, classes_km)
classes_km5 = classes_km + 8
print(s_km5)

#
class_all = np.append(classes_km1,classes_km2)
class_all = np.append(class_all,classes_km3)
class_all = np.append(class_all,classes_km4)
class_all = np.append(class_all,classes_km5)

# y_km = ",".join(str(x) for x in classes_km)
df_km = pd.DataFrame(E,columns=['s'])
df_km.insert(0, 'class', class_all)

ind = []
for i in range(clusters):
    if np.size(df_km[df_km['class']==i],0)<5:
        ind+=(list(np.where(class_all==i)[0]))
df_km = df_km.drop(ind)
df_km = df_km.reset_index(drop=True)

sns.boxplot(x='class',y='s',data=df_km)
for i in range(np.size(u)):
    plt.axhline(y=u[i], color='r', linestyle=':')
#%%
plt.scatter(E,class_all)
# plt.scatter(E, fid, c=class_all, marker='.')
plt.colorbar()
for i in range(np.size(u)):
    plt.axvline(u[i],color='r',ls=':')
plt.xlabel('s')
plt.ylabel('class')
# plt.ylabel('fidelity')
# parallel_coordinates(df_km,'class')
#%% change
class1=[]
for i in classes_km1:
    if i==1:
        class1.append(0)
    if i==0:
        class1.append(1)
        
classes_km1 = np.array(class1)
#%% save
df_e = pd.DataFrame(E)
df_e.to_excel('H111_E.xlsx')
df_km.to_excel('H111_all_T.xlsx')
df_fid_T = pd.DataFrame(data_fid2)
df_fid_T.to_excel('H111_fid_T.xlsx')





