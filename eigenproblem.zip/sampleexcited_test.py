#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Dec 11 04:23:02 2022

@author: kesson
"""
from qiskit.chemistry.drivers import PySCFDriver, UnitsType, HFMethodType, BasisType
from qiskit.chemistry import FermionicOperator
from qiskit.aqua.algorithms import NumPyEigensolver
import matplotlib.pyplot as plt
import numpy as np
from qiskit.providers.aer import AerSimulator,QasmSimulator,StatevectorSimulator
from qiskit import transpile
from qiskit import QuantumCircuit, execute
from qiskit.quantum_info import state_fidelity
from scipy.linalg import expm
from scipy.optimize import minimize
from qiskit.circuit import QuantumCircuit, ParameterVector, Parameter
from ground import groupedFermionicOperator
from numdifftools import Jacobian, Hessian
from qiskit.aqua.operators import WeightedPauliOperator
from qiskit.quantum_info import Pauli
from qiskit.providers.aer.noise import NoiseModel,depolarizing_error, amplitude_damping_error
import time
from qiskit.providers.aer.extensions import *
from qiskit.aqua.algorithms import VQE
from qiskit.aqua.components.optimizers import COBYLA
from qiskit.opflow.gradients import Gradient
from sklearn.cluster import KMeans
#%%
map_type='jordan_wigner'
# backend = StatevectorSimulator(method="statevector")
noise_model = NoiseModel()
errate=0
error = depolarizing_error(errate, 1)
noise_model.add_all_qubit_quantum_error(error,["u1", "u2", "u3"])
errate=0
error = depolarizing_error(errate, 2)
noise_model.add_all_qubit_quantum_error(error,'cx')
sim_noise = QasmSimulator(noise_model=noise_model)
# sim = QasmSimulator()
I  = np.array([[ 1, 0],
               [ 0, 1]])
Sx = np.array([[ 0, 1],
               [ 1, 0]])
Sy = np.array([[ 0,-1j],
               [1j, 0]])
Sz = np.array([[ 1, 0],
               [ 0,-1]])

def get_qubit_op(dist):
    driver = PySCFDriver(atom="H .0 .0 .0; H .0 .0 " + str(dist)#+";H .0 .0 "+str(dist*2)
                          # +";H .0 .0 "+str(dist*3)#+";H .0 .0 "+str(dist*4)#+";H .0 .0 "+str(dist*5)
                         , unit=UnitsType.ANGSTROM,hf_method=HFMethodType.UHF
                        , spin=0,charge=0, basis='sto3g')
    molecule = driver.run()
    repulsion_energy = molecule.nuclear_repulsion_energy
    num_particles = molecule.num_alpha + molecule.num_beta
    num_spin_orbitals = molecule.num_orbitals * 2
    ferOp = FermionicOperator(h1=molecule.one_body_integrals, h2=molecule.two_body_integrals)
    qubitOp = ferOp.mapping(map_type=map_type, threshold=0.00000001)
    #g = groupedFermionicOperator(ferOp, num_particles)
    #qubitOp = g.to_paulis()
    shift =  repulsion_energy
    return qubitOp, num_particles, num_spin_orbitals, shift

def makewave(wavefunction,dele,name):
    n=wavefunction.num_qubits
    param = ParameterVector(name,int(3*n*(n-1)+6*n))
    t=0
    for i in range(n):
        if (t not in dele):
            wavefunction.ry(param[t],i)
        t+=1
    for i in range(n):
        for j in range(n):
            if i!=j and (t not in dele):
                wavefunction.cry(param[t],i,j)
            t+=1
    for i in range(n):
        if (t not in dele):
            wavefunction.ry(param[t],i)
        t+=1
    return wavefunction
# E3=[]
def L(params,wavefunction):
    a={}
    t=0
    for i in wavefunction.parameters:
        a[i]=params[t]
        t+=1
        
    qc = wavefunction.assign_parameters(a)
    qc.snapshot_statevector('final')
    qc.measure_all()
    circ_noise = transpile(qc, sim_noise)
    noise_result = sim_noise.run(circ_noise, shots=1).result()
    u=noise_result.data(0)['snapshots']['statevector']['final'][0]
    # counts = noise_result.get_counts(qc)
    # u=np.zeros(2**wavefunction.num_qubits)
    # for i in list(counts):
    #     u[int(i,2)]=counts[i]
    # u/=sum(u)
    # u=np.sqrt(u)
    # print((v.conj().dot(Hp.dot(v)).real)+shift)
    # E3.append(u.conj().dot(Hp.dot(u)).real)
    return u.conj().dot(Hp.dot(u)).real
    # return -state_fidelity(u,ext)

def dtheta(params,wavefunction,H):
    N=wavefunction.num_parameters
    A=np.zeros([N,N],dtype=np.complex128)
    C=np.zeros(N,dtype=np.complex128)
    phi=Lv(params,wavefunction)
    dpdt=[]
    cp=1/2
    a=np.pi/2
    for i in range(len(params)):
        ptmp1=params.copy()
        ptmp2=params.copy()
        ptmp1[i]+=a
        ptmp2[i]-=a    
        dp=cp*(Lv(ptmp1,wavefunction)-Lv(ptmp2,wavefunction))
        dpdt.append(dp)
    for i in range(len(params)):
        for j in range(len(params)):
            A[i,j]=(dpdt[i].conj().dot(dpdt[j])).real+dpdt[i].conj().dot(phi)*dpdt[j].conj().dot(phi)
    for i in range(len(params)):
        # phi=Lv(params,wavefunction)
        C[i]=(dpdt[i].conj().dot(H.dot(phi))).real
    dx=np.linalg.pinv(A.real).dot(-C)
    return dx.real

def Lv(params,wavefunction):
    a={}
    t=0
    for i in wavefunction.parameters:
        a[i]=params[t]
        t+=1
    qc = wavefunction.assign_parameters(a)
    # qc.snapshot_density_matrix('final')
    qc.snapshot_statevector('final')
    qc.measure_all()
    # U=[]
    # for i in range(100):
    circ_noise = transpile(qc, sim_noise)
    noise_result = sim_noise.run(circ_noise,shots=1).result()
    u=noise_result.data(0)['snapshots']['statevector']['final'][0]
    # U.append(u)
    # u=sum(U)/10
    # counts = noise_result.get_counts(qc)
    # u=np.zeros(2**wavefunction.num_qubits)
    # for i in list(counts):
    #     u[int(i,2)]=counts[i]
    # u/=sum(u)
    # u=np.sqrt(u)
    return u

def commutator(A,B):
    return A.dot(B)-B.dot(A)

def anticommutator(A,B):
    return A.dot(B)+B.dot(A)

def label2Pauli(s): # can be imported from groupedFermionicOperator.py
    """
    Convert a Pauli string into Pauli object. 
    Note that the qubits are labelled in descending order: 'IXYZ' represents I_3 X_2 Y_1 Z_0
    
    Args: 
        s (str) : string representation of a Pauli term
    
    Returns:
        qiskit.quantum_info.Pauli: Pauli object of s
    """
    
    xs = []
    zs = []
    label2XZ = {'I': (0, 0), 'X': (1, 0), 'Y': (1, 1), 'Z': (0, 1)}
    for c in s[::-1]:
        x, z = label2XZ[c]
        xs.append(x)
        zs.append(z)
    return Pauli(z = zs, x = xs)

def str2WeightedPaulis(s):
	s = s.strip()
	IXYZ = ['I', 'X', 'Y', 'Z']
	prev_idx = 0
	coefs = []
	paulis = []
	is_coef = True
	for idx, c in enumerate(s + '+'):
		if idx == 0: continue
		if is_coef and c in IXYZ:
			coef = complex(s[prev_idx : idx].replace('i', 'j'))
			coefs.append(coef)
			is_coef = False
			prev_idx = idx
		if not is_coef and c in ['+', '-']:
			label = s[prev_idx : idx]
			paulis.append(label2Pauli(label))
			is_coef = True
			prev_idx = idx
	return WeightedPauliOperator([[c, p] for (c,p) in zip(coefs, paulis)])

def Tmax(u):
    v=u.copy()
    for i in range(len(v)):
        if abs(v[i]-4*np.pi)<abs(v[i]):
            v[i]=v[i]-4*np.pi
    return v
#%%
vt=[]
dt=1e-1
roop=100
n=1
wavefunction = QuantumCircuit(n)
wavefunction.h(0)
# wavefunction.h(1)
# wavefunction.h(2)
# wavefunction.h(3)
dele=[]
wavefunction = makewave(wavefunction, dele,1)
N=wavefunction.num_parameters
# Hp=Sz.copy()
qubitOp, num_particles, num_spin_orbitals, shift=get_qubit_op(0.74)
# Hp=qubitOp.to_opflow().to_matrix()
Hp=Sz.copy()
u,w=np.linalg.eig(Hp)
x0=np.random.rand(N)*0
cv=Lv(x0, wavefunction)
E1=[]
E=[]
e=-2
for i in range(30):
    e+=0.05
    E.append(e)
    H=(Hp-e*np.eye(2**n)).dot(Hp-e*np.eye(2**n))
    x0=np.random.rand(N)*0
    U=[L(x0,wavefunction)]
    ###########
    for i in range(roop):
        dx0=dtheta(x0, wavefunction, H)
        x0+=(dx0)*dt
        print(x0)
        U.append(L(x0,wavefunction))
        if abs(U[-1]-U[-2])<1e-2:
            break
        # v=Lv(x0, wavefunction)
    E1.append(np.mod(x0,4*np.pi))
    print(e,'\n Energy:',E1[-1])
    
E2=[]
for i in E1:
    E2.append(Tmax(i))
d=[]
for i in range(len(E1)-1):
    d.append(np.linalg.norm(E1[i]-E1[i+1]))

    
